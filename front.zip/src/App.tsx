import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./pages/home/Home";
import AdminDashboard from "./pages/admin/AdminDashboard";
import { useEffect, useState } from "react";
import {
  MyContext,
  type MyContextValue,
  type User,
} from "./pages/admin/MyContext";
import CreatePost from "./pages/admin/create-post/CreatePost";
import Drafts from "./pages/admin/drafts/Drafts";
import EditPost from "./pages/admin/edit-post/EditPost";
import EditDraft from "./pages/admin/edit-draft/EditDraft";
import Categories from "./pages/admin/categories/Categories";
import Comments from "./pages/admin/comments/Comments";
import Settings from "./pages/admin/settings/Settings";
import PostDetails from "./pages/post-details/PostDetails";
import AdminLayout from "./layouts/AdminLayout";
import Posts from "./pages/admin/posts/Posts";
import MainBodyCreatePost from "./pages/admin/create-post/MainBody";
import MainBodyEditPost from "./pages/admin/edit-post/MainBody";
import MainBodyDrafts from "./pages/admin/drafts/MainBody";
import MainBodyEditDrafts from "./pages/admin/edit-draft/MainBody";
import MainBodyCategories from "./pages/admin/categories/MainBody";
import MainBodyComments from "./pages/admin/comments/MainBody";
import MainBodyEditComment from "./pages/admin/edit-comment/MainBody";
import MainBodySettings from "./pages/admin/settings/MainBody";
import { Toaster } from "react-hot-toast";
import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";
import Api from "./utils/Api";
import axios from "axios";
import "./App.css";

function App() {
  const [openOverlay, setOpenOverlay] = useState(false);
  const [activeTab, setActiveTab] = useState("Posts");
  // count states
  const [countPublished, setCountPublished] = useState(0);
  const [countDraft, setCountDraft] = useState(0);
  const [countCategories, setCountCategories] = useState(0);
  const [countComments, setCountComments] = useState(0);
  const [user, setUser] = useState<User | null>(null);
  const [darkMode, setDarkMode] = useState(false);

  // get count publisged posts
  const getCountPublished = async () => {
    const config = {
      method: "GET",
      url: `${Api}/post/countPublished`,
    };
    await axios(config)
      .then((result) => {
        setCountPublished(result.data[0].count_published);
      })
      .catch((error) => console.log(error));
  };

  // get count draft posts
  const getCountDraft = async () => {
    const config = {
      method: "GET",
      url: `${Api}/post/countDraft`,
    };
    await axios(config)
      .then((result) => {
        setCountDraft(result.data[0].count_draft);
      })
      .catch((error) => console.log(error));
  };

  // get count categories
  const getCountCategories = async () => {
    const config = {
      method: "GET",
      url: `${Api}/category/countCategories`,
    };
    await axios(config)
      .then((result) => {
        setCountCategories(result.data[0].count_categories);
      })
      .catch((error) => console.log(error));
  };

  // get count comments
  const getCountComments = async () => {
    const config = {
      method: "GET",
      url: `${Api}/comment/countComments`,
    };
    await axios(config)
      .then((result) => {
        setCountComments(result.data[0].count_comments);
      })
      .catch((error) => console.log(error));
  };

  const contextValue: MyContextValue = {
    openOverlay,
    setOpenOverlay,
    activeTab,
    setActiveTab,
    countPublished,
    setCountPublished,
    countDraft,
    setCountDraft,
    countCategories,
    setCountCategories,
    countComments,
    setCountComments,
    user,
    setUser,
    darkMode,
    setDarkMode,
  };

  useEffect(() => {
    getCountPublished();
    getCountDraft();
    getCountCategories();
    getCountComments();
  });

  return (
    <MyContext.Provider value={contextValue}>
      <Toaster position="top-center" />
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route
            path="/admin/posts"
            element={<AdminLayout mainBody={<Posts />} />}
          />
          <Route
            path="/admin/create-post"
            element={<AdminLayout mainBody={<MainBodyCreatePost />} />}
          />
          <Route
            path="/admin/edit-post/:id"
            element={<AdminLayout mainBody={<MainBodyEditPost />} />}
          />
          <Route
            path="/admin/drafts"
            element={<AdminLayout mainBody={<MainBodyDrafts />} />}
          />
          <Route
            path="/admin/edit-draft/:id"
            element={<AdminLayout mainBody={<MainBodyEditDrafts />} />}
          />
          <Route
            path="/admin/categories"
            element={<AdminLayout mainBody={<MainBodyCategories />} />}
          />
          <Route
            path="/admin/comments"
            element={<AdminLayout mainBody={<MainBodyComments />} />}
          />
          <Route
            path="/admin/edit-comment/:id"
            element={<AdminLayout mainBody={<MainBodyEditComment />} />}
          />
          <Route
            path="/admin/settings"
            element={<AdminLayout mainBody={<MainBodySettings />} />}
          />
          <Route path="/" element={<Home />} />
          <Route path="/post-details/:id" element={<PostDetails />} />
        </Routes>
      </BrowserRouter>
    </MyContext.Provider>
  );
}

export default App;
