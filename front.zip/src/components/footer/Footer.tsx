import { useContext } from "react";
import { MyContext } from "../../pages/admin/MyContext";

const Footer = () => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { darkMode } = context;

  return (
    <div className={`border-t-1 py-7 ${
      darkMode 
        ? 'border-gray-700 bg-gray-900' 
        : 'border-gray-200 bg-gray-50'
    }`}>
      <h3 className={`text-sm text-center ${
        darkMode ? 'text-gray-400' : 'text-gray-500'
      }`}>
        © 2025 Blog CMS. All rights reserved.
      </h3>
    </div>
  );
};

export default Footer;
