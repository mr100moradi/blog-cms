import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSearch } from "@fortawesome/free-solid-svg-icons";
import "./Search.css";
import { useState } from "react";

const Search = () => {
  const [selectedJobs, setSelectedJobs] = useState(false);
  const [selectedprojects, setSelectedJprojects] = useState(false);

  return (
    <div className="px-4 md:px-36 my-10">
      <div className="flex flex-col justify-center items-center gap-7 text-white shadow-xl p-8 rounded-3xl bg-gradient-to-br from-amber-500 via-orange-500 to-red-500  ">
        <h1 className="font-bold text-3xl md:text-6xl">Find Your Dream Job or</h1>
        <h1 className="font-bold text-3xl md:text-6xl">Hire Top Talent</h1>
        <h3 className="text-xl md:text-2xl text-center text-amber-100">
          Connect with the best opportunities and professionals in the industry
        </h3>
        <div className="flex flex-wrap gap-4 bg-white/10 backdrop-blur-sm p-2 rounded-2xl">
          <div className="flex gap-2 items-center bg-white/10 backdrop-blur-sm p-2 rounded-xl">
            <FontAwesomeIcon icon={faSearch} size="lg" />
            <input
              type="text"
              placeholder="Search jobs, skills, or companies..."
              className="w-72 outline-none"
            />
          </div>
          <div className="flex gap-2 items-center">
            {selectedJobs ? (
              <div
                className="cursor-pointer rounded-xl px-6 py-3 font-medium transition-all bg-white text-amber-600"
                //   onClick={() => {setSelectedJobs(false)}}
              >
                Jobs
              </div>
            ) : (
              <div
                className="cursor-pointer rounded-xl px-6 py-3 font-medium transition-all bg-white/20 text-white hover:bg-white/30"
                onClick={() => {
                  setSelectedJobs(true);
                  setSelectedJprojects(false);
                }}
              >
                Jobs
              </div>
            )}
            {selectedprojects ? (
              <div
                className="cursor-pointer rounded-xl px-6 py-3 font-medium transition-all bg-white text-amber-600"
                // onClick={() => {setSelectedJprojects(false);}}
              >
                projects
              </div>
            ) : (
              <div
                className="cursor-pointer rounded-xl px-6 py-3 font-medium transition-all bg-white/20 text-white hover:bg-white/30"
                onClick={() => {
                  setSelectedJprojects(true);
                  setSelectedJobs(false);
                }}
              >
                projects
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Search;
