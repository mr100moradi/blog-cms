import { useNavigate } from "react-router-dom";
import { useContext } from "react";
import { MyContext } from "../../pages/admin/MyContext";
import "./SidebarItem.css";

const SidebarItem = (props: any) => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { setOpenOverlay,activeTab, setActiveTab, darkMode } = context;

  const navigate = useNavigate();

  return (
    <button
      className={`cursor-pointer flex justify-between items-center w-full rounded-lg px-3 py-2 my-0.5 text-sm ${
        activeTab === props.title 
          ? darkMode 
            ? "bg-blue-900 text-blue-300" 
            : "bg-blue-50 text-blue-700"
          : darkMode
            ? "text-gray-300 hover:bg-gray-700"
            : "text-gray-700 hover:bg-gray-100"
      }`}
      onClick={() => {
        navigate(props.to);
        setActiveTab(props.title);
        // setOpenOverlay(false);
      }}
    >
      <div className="flex items-center gap-2">
        <props.icon className="h-5 w-5" />
        <span className="capitalize ml-1">{props.title}</span>
      </div>
      {props.count && (
        <span className={`text-xs rounded-sm px-2 p-0.5 ${
          darkMode 
            ? "bg-gray-700 text-gray-300" 
            : "bg-gray-300 text-gray-700"
        }`}>
          {props.count}
        </span>
      )}
    </button>
  );
};

export default SidebarItem;
