import {
  NewspaperIcon,
  FolderOpenIcon,
  Cog6ToothIcon,
  DocumentTextIcon,
  ChatBubbleLeftRightIcon,
} from "@heroicons/react/24/outline";
import { useContext } from "react";
import SidebarItem from "./SidebarItem";
import { MyContext } from "../../pages/admin/MyContext";
import "./Navbar.css";

const Navbar = (props: any) => {
  // get context
  const context = useContext(MyContext);
  if (!context) return null;
  const { countPublished, countDraft, countCategories, countComments, darkMode } =
    context;

  return (
    <div className={`fadeRight hidden md:flex flex-col w-80 h-dvh ${darkMode ? 'bg-gray-800 border-r-gray-700' : 'bg-white border-r-gray-300'} border-r-1 p-3`}>
      <SidebarItem
        title="Posts"
        icon={NewspaperIcon}
        count={countPublished.toString()}
        to="/admin/posts"
      />
      <SidebarItem
        title="Drafts"
        icon={DocumentTextIcon}
        count={countDraft.toString()}
        to="/admin/drafts"
      />
      <SidebarItem
        title="Categories"
        icon={FolderOpenIcon}
        count={countCategories.toString()}
        to="/admin/categories"
      />
      <SidebarItem
        title="Comments"
        icon={ChatBubbleLeftRightIcon}
        count={countComments.toString()}
        to="/admin/comments"
      />
      <SidebarItem
        title="Settings"
        icon={Cog6ToothIcon}
        count={null}
        to="/admin/settings"
      />
      {/* {token && (
            <>
              {user?.userType === "employee" && (
                <Link
                  to={"/user-profile/" + user._id}
                  className="cursor-pointer capitalize text-gray-600 transition-all hover:text-black"
                >
                  profile
                </Link>
              )}
              {user?.userType === "employer" && (
                <Link
                  to="/admin"
                  className="cursor-pointer capitalize text-gray-600 transition-all hover:text-black"
                >
                  dashboard
                </Link>
              )}
              <button
                className="cursor-pointer capitalize text-gray-600 transition-all hover:text-black"
                onClick={(e) => logout(e)}
              >
                logout
              </button>
            </>
          )}
          {!token && (
            <>
              <Link
                to="/auth"
                className="cursor-pointer capitalize text-gray-600 transition-all hover:text-black"
              >
                login
              </Link>
              <Link
                to="/auth"
                className="cursor-pointer capitalize bg-gradient-to-r from-amber-500 to-orange-500 text-white w-20 px-3 py-2  rounded-lg transition-all hover:scale-105"
              >
                sign up
              </Link>
            </>
          )} */}
    </div>
  );
};

export default Navbar;
