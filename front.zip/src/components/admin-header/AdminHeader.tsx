import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBars, faClose } from "@fortawesome/free-solid-svg-icons";
import Menu from "./Menu";
import "./AdminHeader.css";
import { useContext } from "react";
import { MyContext } from "../../pages/admin/MyContext";

const AdminHeader = (props: any) => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { openOverlay, setOpenOverlay, darkMode } = context;

  return (
    <header>
      <div className={`fadeBotton fixed w-full border-b-1 ${darkMode ? 'border-b-gray-700 bg-gray-800/90' : 'border-b-gray-200 bg-white/90'} backdrop-blur-lg`}>
        <div className="px-4 md:px-24 py-4">
          <div className="flex">
            <button
              className={`cursor-pointer block md:hidden ${darkMode ? 'text-gray-300 border-gray-600 bg-gray-700' : 'text-gray-500 border-gray-200'} p-2 shadow border rounded-lg`}
              onClick={() => {
                props.setMobileMenu(true);
                setOpenOverlay(true);
              }}
            >
              <FontAwesomeIcon icon={props.mobileMenu ? faClose : faBars} />
            </button>
            <Link
              to="/admin"
              className="flex items-center gap-3 transition-all hover:scale-105 max-w-44 ml-5"
            >
              <div className="shadow bg-gradient-to-br from-blue-500 to-blue-700 text-white px-3 py-1.5 rounded-lg">
                <span className="capitalize font-bold transition-all hover:opacity-0 ">
                  B
                </span>
              </div>
              <div className="flex flex-col">
                <span className={`capitalize text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Simple</span>
                <span className={`capitalize font-bold text-lg w-full ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  Blog CMS
                </span>
              </div>
            </Link>

            <Menu />
          </div>
        </div>
      </div>
    </header>
  );
};

export default AdminHeader;
