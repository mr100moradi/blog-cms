import { Link, useNavigate } from "react-router-dom";
import Cookies from "universal-cookie";
import "./Menu.css";
import { MoonIcon, SunIcon } from "@heroicons/react/24/outline";
import { useContext } from "react";
import { MyContext } from "../../pages/admin/MyContext";

const Menu = (props: any) => {
  // get cookies
  const cookies = new Cookies();

  const navigate = useNavigate();

  // get context
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { darkMode, setDarkMode } = context;

  const logout = (e: any) => {
    e.preventDefault();
    cookies.remove("TOKEN", { path: "/" });
    cookies.remove("USER", { path: "/" });
    navigate("/login");
  };

  return (
    <>
      <div className="flex justify-start items-center ml-auto gap-5 mt-10 md:mt-0">
        <button
          className={`cursor-pointer border ${darkMode ? 'border-gray-600 bg-gray-800 text-yellow-400' : 'border-gray-300'} rounded-lg p-2 transition-all`}
          aria-label="Toggle theme"
          onClick={() => setDarkMode(!darkMode)}
        >
          {darkMode ? (
            <SunIcon className="w-5 h-5" />
          ) : (
            <MoonIcon className="w-5 h-5" />
          )}
        </button>
        <Link
          to={"/"}
          className={`cursor-pointer capitalize ${darkMode ? 'text-gray-300 hover:text-white' : 'text-gray-600 hover:text-black'} transition-all`}
        >
          posts
        </Link>
        <button
          className={`cursor-pointer capitalize ${darkMode ? 'text-gray-300 hover:text-white' : 'text-gray-600 hover:text-black'} transition-all`}
          onClick={(e) => logout(e)}
        >
          logout
        </button>
      </div>
    </>
  );
};

export default Menu;
