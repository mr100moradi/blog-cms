import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faClose, faUser } from "@fortawesome/free-solid-svg-icons";
import SidebarItem from "../navbar/SidebarItem";
import "./MobileMenu.css";
import { useContext, useEffect, useState } from "react";
import axios from "axios";
import Api from "../../utils/Api";
import { MyContext } from "../../pages/admin/MyContext";
import { ChatBubbleLeftRightIcon, Cog6ToothIcon, DocumentTextIcon, FolderOpenIcon, NewspaperIcon } from "@heroicons/react/24/outline";

const MobileMenu = (props: any) => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { openOverlay, setOpenOverlay, darkMode } = context;

  const [countPublished, setCountPublished] = useState(0);
  const [countDraft, setCountDraft] = useState(0);
  const [countCategories, setCountCategories] = useState(0);
  const [countComments, setCountComments] = useState(0);

  // get count publisged posts
  const getCountPublished = async () => {
    const config = {
      method: "GET",
      url: `${Api}/post/countPublished`,
    };
    await axios(config)
      .then((result) => {
        setCountPublished(result.data[0].count_published);
      })
      .catch((error) => console.log(error));
  };

  // get count draft posts
  const getCountDraft = async () => {
    const config = {
      method: "GET",
      url: `${Api}/post/countDraft`,
    };
    await axios(config)
      .then((result) => {
        setCountDraft(result.data[0].count_draft);
      })
      .catch((error) => console.log(error));
  };

  // get count categories
  const getCategories = async () => {
    const config = {
      method: "GET",
      url: `${Api}/category/countCategories`,
    };
    await axios(config)
      .then((result) => {
        setCountCategories(result.data[0].count_categories);
      })
      .catch((error) => console.log(error));
  };

  // get count comments
  const getCountComments = async () => {
    const config = {
      method: "GET",
      url: `${Api}/comment/countComments`,
    };
    await axios(config)
      .then((result) => {
        setCountComments(result.data[0].count_comments);
      })
      .catch((error) => console.log(error));
  };

  useEffect(() => {
    getCountPublished();
    getCountDraft();
    getCategories();
    getCountComments();
  }, []);

  return (
    <div className={`fixed top-0 shadow w-72 h-dvh p-4 z-2 ${
      darkMode ? 'bg-gray-800' : 'bg-white'
    }`}>
      <div className="flex justify-between items-center">
        <span className={`capitalize font-semibold ${
          darkMode ? 'text-white' : 'text-gray-900'
        }`}>Menu</span>
        <button
          className={`cursor-pointer border rounded-lg px-4 py-1.5 transition-all ${
            darkMode 
              ? 'border-gray-600 hover:bg-gray-700' 
              : 'border-gray-300 hover:bg-gray-50'
          }`}
          onClick={() => {
            props.setMobileMenu(false);
            setOpenOverlay(false);
          }}
        >
          <FontAwesomeIcon icon={faClose} className={`text-md ${
            darkMode ? 'text-gray-300' : 'text-gray-500'
          }`} />
        </button>
      </div>
      <div className="mt-4">
        <SidebarItem
          title="Posts"
          icon={NewspaperIcon}
          count={countPublished}
          to="/admin/posts"
        />
        <SidebarItem
          title="Drafts"
          icon={DocumentTextIcon}
          count={countDraft}
          to="/admin/drafts"
        />
        <SidebarItem
          title="Categories"
          icon={FolderOpenIcon}
          count={countCategories}
          to="/admin/categories"
        />
        <SidebarItem
          title="Comments"
          icon={ChatBubbleLeftRightIcon}
          count={countComments}
          to="/admin/comments"
        />
        <SidebarItem
          title="Settings"
          icon={Cog6ToothIcon}
          count={null}
          to="/admin/settings"
        />
      </div>
      {/* {token && (
            <>
              {user?.userType === "employee" && (
                <Link
                  to={"/user-profile/" + user._id}
                  className="cursor-pointer capitalize text-gray-600 transition-all hover:text-black"
                >
                  profile
                </Link>
              )}
              {user?.userType === "employer" && (
                <Link
                  to="/admin"
                  className="cursor-pointer capitalize text-gray-600 transition-all hover:text-black"
                >
                  dashboard
                </Link>
              )}
              <button
                className="cursor-pointer capitalize text-gray-600 transition-all hover:text-black"
                onClick={(e) => logout(e)}
              >
                logout
              </button>
            </>
          )}
          {!token && (
            <>
              <Link
                to="/auth"
                className="cursor-pointer capitalize text-gray-600 transition-all hover:text-black"
              >
                login
              </Link>
              <Link
                to="/auth"
                className="cursor-pointer capitalize bg-gradient-to-r from-amber-500 to-orange-500 text-white w-20 px-3 py-2  rounded-lg transition-all hover:scale-105"
              >
                sign up
              </Link>
            </>
          )} */}
    </div>
  );
};

export default MobileMenu;
