import { Link, useNavigate } from "react-router-dom";
import "./HomeHeader.css";
import Cookies from "universal-cookie";
import { useContext } from "react";
import { MyContext } from "../../pages/admin/MyContext";
import { MoonIcon, SunIcon } from "@heroicons/react/24/outline";

const HomeHeader = (props: any) => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { darkMode, setDarkMode } = context;
  // get cookies
  const cookies = new Cookies();
  const user = cookies.get("USER");

  const navigate = useNavigate();

  const logout = (e: any) => {
    e.preventDefault();
    cookies.remove("TOKEN", { path: "/" });
    cookies.remove("USER", { path: "/" });
    navigate("/login");
  };

  return (
    <header>
      <div className={`fadeBotton fixed w-full border-b-1 backdrop-blur-lg ${
        darkMode 
          ? 'border-b-gray-700 bg-gray-800/90' 
          : 'border-b-gray-200 bg-white/90'
      }`}>
        <div className="px-4 md:px-24 py-4">
          <div className="flex justify-between items-center">
            <Link
              to="/"
              className="flex items-center gap-3 transition-all hover:scale-105 max-w-44 ml-5"
            >
              <div className="shadow bg-gradient-to-br from-blue-500 to-blue-700 text-white px-3 py-1.5 rounded-lg">
                <span className="capitalize font-bold transition-all hover:opacity-0 ">
                  B
                </span>
              </div>
              <div className="flex flex-col">
                <span className={`capitalize font-bold text-lg w-full ${
                  darkMode ? 'text-white' : 'text-gray-900'
                }`}>
                  Blog
                </span>
                <span className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Learn and explore</span>
              </div>
            </Link>
            <div className="flex items-center gap-3">
              <button
                className={`cursor-pointer border rounded-lg p-2 transition-all ${
                  darkMode 
                    ? 'border-gray-600 bg-gray-700 text-yellow-400' 
                    : 'border-gray-300'
                }`}
                aria-label="Toggle theme"
                onClick={() => setDarkMode(!darkMode)}
              >
                {darkMode ? (
                  <SunIcon className="w-5 h-5" />
                ) : (
                  <MoonIcon className="w-5 h-5" />
                )}
              </button>
              {user?.user_type === "user" && (
                <>
                  <Link
                    to="/"
                    className={`capitalize text-sm transition-all ${
                      darkMode 
                        ? 'text-gray-300 hover:text-blue-400' 
                        : 'hover:text-blue-600'
                    }`}
                  >
                    Posts
                  </Link>
                  <button
                    className={`cursor-pointer capitalize text-sm ml-3 transition-all ${
                      darkMode 
                        ? 'text-gray-300 hover:text-blue-400' 
                        : 'hover:text-blue-600'
                    }`}
                    onClick={(e)=>logout(e)}
                  >
                    Logout
                  </button>
                </>
              )}
              {user?.user_type === "admin" && (
                <Link
                  to="/admin"
                  className={`capitalize text-sm transition-all ${
                    darkMode 
                      ? 'text-gray-300 hover:text-blue-400' 
                      : 'hover:text-blue-600'
                  }`}
                >
                  Dashboard
                </Link>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default HomeHeader;
