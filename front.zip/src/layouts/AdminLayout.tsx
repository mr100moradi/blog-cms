import { useContext, useEffect, useState } from "react";
import "./AdminLayout.css";
import AdminHeader from "../components/admin-header/AdminHeader";
import Navbar from "../components/navbar/Navbar";
import MobileMenu from "../components/admin-header/MobileMenu";
import { MyContext } from "../pages/admin/MyContext";
import Cookies from "universal-cookie";
import { useNavigate } from "react-router-dom";

const AdminLayout = (props: any) => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { openOverlay, setOpenOverlay, darkMode } = context;

  // get token from cookies
  const cookies = new Cookies();
  const token = cookies.get("TOKEN");

  const navigate = useNavigate();

  // mobile menu state
  const [mobileMenu, setMobileMenu] = useState(false);

  useEffect(() => {
    if (!token) {
      navigate("/login");
    }
  });

  return (
    <div className={`relative ${darkMode ? "dark" : ""}`}>
      {openOverlay && (
        <div
          className={`fixed w-dvw h-dvh ${
            darkMode ? "bg-white/10" : "bg-black/10"
          } backdrop-blur-xs z-2`}
          onClick={() => {
            setMobileMenu(false);
            setOpenOverlay(false);
          }}
        ></div>
      )}

      <AdminHeader mobileMenu={mobileMenu} setMobileMenu={setMobileMenu} />

      <main
        className={`px-4 md:px-28 py-8 ${
          darkMode ? "bg-gray-900" : "bg-gray-50"
        }`}
      >
        <div className="w-full flex mt-20 z-0">
          <Navbar />
          {props.mainBody}
        </div>
      </main>

      {mobileMenu && (
        <MobileMenu mobileMenu={mobileMenu} setMobileMenu={setMobileMenu} />
      )}
    </div>
  );
};

export default AdminLayout;
