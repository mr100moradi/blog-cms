import { useContext, useEffect, useState } from "react";
import axios from "axios";
import Api from "../../utils/Api";
import { useParams } from "react-router-dom";
import Tags from "../admin/posts/Tags";
import "./MainBody.css";
import { MyContext } from "../admin/MyContext";
import Cookies from "universal-cookie";

const MainBody = () => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { darkMode } = context;

  // get cookies
  const cookies = new Cookies();
  const user = cookies.get("USER");

  // get parameters
  const { id } = useParams();

  // get content state
  const [post, setPost] = useState({});
  const [category, setCategory] = useState({});

  // comment state for submit comment
  const [comment, setComment] = useState("");

  // comments state for get list comments
  const [comments, setComments] = useState([]);

  // get category
  const getCategory = async (categoryId: any) => {
    const config = {
      method: "GET",
      url: `${Api}/category/single/${categoryId}`,
    };

    await axios(config)
      .then((result) => {
        setCategory(result.data);
      })
      .catch((error) => console.log(error));
  };

  // get post
  const getPost = async () => {
    const config = {
      method: "GET",
      url: `${Api}/post/single/${id}`,
    };
    await axios(config)
      .then((result) => {
        // console.log(result.data);
        getCategory(result.data.category_id);
        setPost(result.data);
      })
      .catch((error) => console.log(error));
  };

  // handle submit for comment
  const handleSubmit = async (e: any, postId) => {
    e.preventDefault();

    const fullName = user.first_name + " " + user.last_name;

    const config = {
      method: "POST",
      url: `${Api}/comment/add`,
      data: {
        fullName,
        comment,
        postId,
      },
    };
    await axios(config)
      .then((result) => {
        // console.log(result.data);
        getComments();
      })
      .catch((error) => console.log(error));
  };

  // handle submit for comment
  const getComments = async () => {
    const config = {
      method: "GET",
      url: `${Api}/comment`,
    };
    await axios(config)
      .then((result) => {
        // console.log(result.data);
        setComments(result.data);
      })
      .catch((error) => console.log(error));
  };

  useEffect(() => {
    getPost();
    getComments();
  }, []);

  return (
    <div className="mt-20">
      <div
        className={`zoomBody border rounded-2xl px-5 py-7 ${
          darkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"
        }`}
      >
        <h3
          className={`capitalize font-bold text-xl ${
            darkMode ? "text-white" : "text-gray-900"
          }`}
        >
          {post.title}
        </h3>

        <div className="flex flex-col gap-2 mt-2">
          <span
            className={`text-sm ${
              darkMode ? "text-gray-400" : "text-gray-600"
            }`}
          >
            {new Date(post.created_at).toLocaleString()}
          </span>
          <span
            className={`text-xs ${
              darkMode ? "text-gray-300" : "bg-white text-gray-600"
            }`}
          >
            Category: {category.name}
          </span>
          <Tags tags={post.tags} />
        </div>
        <p
          className={`text-sm mt-10 ${
            darkMode ? "text-gray-300" : "text-gray-700"
          }`}
        >
          {post.content}
        </p>
      </div>
      <div
        className={`zoomBody border rounded-2xl px-5 py-7 mt-10 ${
          darkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"
        }`}
      >
        <h3
          className={`capitalize font-bold text-xl ${
            darkMode ? "text-white" : "text-gray-900"
          }`}
        >
          Comments
        </h3>
        <form
          onSubmit={(e) => handleSubmit(e, post.id)}
          className="mt-4 space-y-3"
        >
          <div>
            <label
              className={`block text-sm ${
                darkMode ? "text-gray-300" : "text-gray-600"
              }`}
            >
              Your comment
            </label>
            <input
              rows="4"
              required
              className={`mt-1 w-full rounded-lg border px-3 py-2 text-sm outline-none ring-0 placeholder:text-gray-400 focus:border-blue-500 ${
                darkMode
                  ? "border-gray-600 bg-gray-700 text-white"
                  : "border-gray-200 bg-white"
              }`}
              placeholder="Write your comment"
              value={comment}
              onChange={(e: any) => setComment(e.target.value)}
            ></input>
          </div>
          <div className="flex justify-end">
            <button
              type="submit"
              className="cursor-pointer text-sm bg-gradient-to-br from-blue-500 to-blue-700 hover:to-blue-900 text-white px-4 py-2 rounded-lg"
            >
              Submit comment
            </button>
          </div>
        </form>
        {comments.filter((comment) => comment.post_id === Number(id)).length >
        0 ? (
          comments
            .filter((comment) => comment.post_id === Number(id))
            .map((comment, index) => (
              <div key={index} className="mt-6 space-y-4">
                <div
                  className={`rounded-lg border p-4 ${
                    darkMode
                      ? "border-gray-700 bg-gray-700"
                      : "border-gray-200 bg-white"
                  }`}
                >
                  <div
                    className={`flex items-center justify-between text-xs ${
                      darkMode ? "text-gray-400" : "text-gray-500"
                    }`}
                  >
                    <span>{comment.name}</span>
                    <span>{new Date(comment.created_at).toLocaleString()}</span>
                  </div>
                  <p
                    className={`mt-2 text-sm ${
                      darkMode ? "text-gray-200" : "text-gray-800"
                    }`}
                  >
                    {comment.comment}
                  </p>
                </div>
              </div>
            ))
        ) : (
          <div className="mt-6 space-y-4">
            <p
              className={`text-sm ${
                darkMode ? "text-gray-400" : "text-gray-600"
              }`}
            >
              No comments yet.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MainBody;
