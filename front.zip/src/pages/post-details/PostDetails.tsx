import Footer from "../../components/footer/Footer";
import HomeHeader from "../../components/home-header/HomeHeader";
import MainBody from "./MainBody";
import "./PostDetails.css";
import { useContext } from "react";
import { MyContext } from "../admin/MyContext";

const PostDetails = () => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { darkMode } = context;

  return (
    <div className={darkMode ? 'dark' : ''}>
      <HomeHeader />

      <main className={`px-4 md:px-72 py-8 ${darkMode ? 'bg-gray-900' : 'bg-gray-50'}`}>
        <MainBody />
      </main>

      <Footer />
    </div>
  );
};

export default PostDetails;
