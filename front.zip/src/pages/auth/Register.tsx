import { Link, useNavigate } from "react-router-dom";
import "./Register.css";
import axios from "axios";
import Api from "../../utils/Api";
import Cookies from "universal-cookie";
import { useContext, useState } from "react";
import { MyContext } from "../admin/MyContext";
import toast from "react-hot-toast";

const Register = () => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { setUser } = context;

  const cookies = new Cookies();
  const navigate = useNavigate();

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [userType, setUserType] = useState("user");

  const handleSubmit = async (e: any) => {
    e.preventDefault();

    const config = {
      method: "POST",
      url: `${Api}/user/register`,
      data: {
        firstName,
        lastName,
        email,
        password,
        confirmPassword,
        userType,
      },
    };

    await axios(config)
      .then((result) => {
        console.log(result.data);

        cookies.set("TOKEN", result.data.token, {
          path: "/",
        });
        cookies.set("USER", result.data.user, {
          path: "/",
        });

        setUser(result.data.user);

        if (result.data.success) {
          toast.success(<div>{result.data.message}</div>,{
            duration:8000,
          });

          // setFirstName("");
          // setLastName("");
          // setEmail("");
          // setPassword("");
          // setConfirmPassword("");
          // setUserType("");

          const userType = result.data.user.user_type;

          if (userType === "admin") {
            navigate("/admin");
          }
          if (userType === "user") {
            navigate("/");
          }
        } else {
          toast.error(<div>{result.data.message}</div>,{
            duration:8000,
          });
        }
      })
      .catch((error) => console.log(error));
  };

  return (
    <div className="flex flex-col justify-center items-center gap-3 w-md mx-auto my-12 p-4 bg-white border border-gray-200 rounded-xl">
      <span className="flex justify-center items-center size-16 bg-amber-700 p-2 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 text-white text-2xl font-bold">
        B
      </span>
      <span className="capitalize font-bold text-2xl">Sign Up</span>
      <span className="capitalize text-sm text-gray-500">
        Create a new account
      </span>
      <form onSubmit={(e) => handleSubmit(e)} className="w-full space-y-4 p-5">
        <div>
          <label className="mb-1 block text-sm font-medium">First Name</label>
          <input
            className="w-full border border-gray-300 rounded-lg p-2 text-sm focus:border-blue-500"
            placeholder="Enter your first name"
            required
            type="text"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
          />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">Last Name</label>
          <input
            className="w-full border border-gray-300 rounded-lg p-2 text-sm focus:border-blue-500"
            placeholder="Enter your last name"
            required
            type="text"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
          />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">Email</label>
          <input
            className="w-full border border-gray-300 rounded-lg p-2 text-sm focus:border-blue-500"
            placeholder="example@email.com"
            required
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">Password</label>
          <input
            className="w-full border border-gray-300 rounded-lg p-2 text-sm focus:border-blue-500"
            placeholder="••••••••"
            required
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">
            Confirm Password
          </label>
          <input
            className="w-full border border-gray-300 rounded-lg p-2 text-sm focus:border-blue-500"
            placeholder="••••••••"
            required
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
          />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">User Type</label>
          <select
            className="w-full border border-gray-300 rounded-lg p-2 text-sm focus:border-blue-500"
            value={userType}
            onChange={(e) => setUserType(e.target.value)}
          >
            <option value="user">Regular User</option>
            <option value="admin">Admin</option>
          </select>
        </div>
        <button
          type="submit"
          className="cursor-pointer text-sm bg-gradient-to-br from-blue-500 to-blue-700 hover:to-blue-900 text-white w-full px-3 py-2 rounded-lg"
        >
          Sign Up
        </button>
      </form>
      <div className="flex items-center gap-1">
        <span className="text-sm text-gray-500">Already have an account?</span>
        <Link to="/login" className="text-sm text-blue-500 hover:text-blue-700">
          Login
        </Link>
      </div>
    </div>
  );
};

export default Register;
