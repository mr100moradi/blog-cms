import { useNavigate } from "react-router-dom";
import { useEffect, useState, useContext } from "react";
import Api from "../../utils/Api";
import axios from "axios";
import Tags from "../admin/posts/Tags";
import Category from "../admin/posts/Category";
import Pagination from "../admin/posts/Pagination";
import "./MainBody.css";
import { MyContext } from "../admin/MyContext";

const MainBody = (props: any) => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { darkMode } = context;
  const navigate = useNavigate();

  // content states
  const [categories, setCategories] = useState([]);
  const [posts, setPosts] = useState([]);

  // filter states
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  const [perPage, setPerPage] = useState(6);

  // pagination states
  const [currentPage, setCurrentPage] = useState(1);

  // filter posts
  const filteredPosts = posts?.filter((post: any) => {
    const searchLower = search.toLowerCase();

    const matchesPublished = post.status === "published";

    const matchesSearch =
      post.title.toLowerCase().includes(searchLower) ||
      post.content.toLowerCase().includes(searchLower);

    const matchesPost =
      category === "all" || post.category_id.toString() === category;

    return matchesPublished && matchesSearch && matchesPost;
  });

  // pagination posts
  const totalPages = Math.ceil(filteredPosts.length / perPage);
  const filteredPostsPaginated = filteredPosts.slice(
    (currentPage - 1) * perPage,
    currentPage * perPage
  );

  // get categories
  const getCategories = async () => {
    const config = {
      method: "GET",
      url: `${Api}/category`,
    };
    await axios(config)
      .then((result) => {
        // console.log(result.data);
        setCategories(result.data);
      })
      .catch((error) => console.log(error));
  };

  const getPosts = async () => {
    const config = {
      method: "GET",
      url: `${Api}/post`,
    };
    await axios(config)
      .then((result) => {
        // console.log(result.data);
        setPosts(result.data);
      })
      .catch((error) => console.log(error));
  };

  useEffect(() => {
    getCategories();
    getPosts();
  }, []);

  return (
    <div className="px-7 space-y-5 mt-20">
      <div className="zoomBody flex flex-col">
        <span
          className={`capitalize font-bold text-xl ${
            darkMode ? "text-white" : "text-gray-900"
          }`}
        >
          Latest posts
        </span>
        <span
          className={`text-sm ${darkMode ? "text-gray-400" : "text-gray-700"}`}
        >
          Browse recently published articles.
        </span>
      </div>
      <div
        className={`zoomBody flex items-center flex-wrap gap-3 rounded-xl border p-4 shadow-sm ${
          darkMode ? "border-gray-700 bg-gray-800" : "border-gray-200 bg-white"
        }`}
      >
        <div className="flex flex-1 items-center flex-wrap gap-3">
          <div className="md:w-72">
            <label
              className={`block text-xs ${
                darkMode ? "text-gray-400" : "text-gray-500"
              }`}
            >
              Search
            </label>
            <input
              placeholder="Search posts"
              className={`mt-1 w-full rounded-lg border px-3 py-2 text-sm outline-none ring-0 placeholder:text-gray-400 focus:border-blue-500 ${
                darkMode
                  ? "border-gray-600 bg-gray-700 text-white"
                  : "border-gray-200 bg-white"
              }`}
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="md:w-56">
            <label
              className={`block text-xs ${
                darkMode ? "text-gray-400" : "text-gray-500"
              }`}
            >
              Category
            </label>
            <select
              className={`w-auto border text-sm rounded-lg p-2 focus:border-blue-500 ${
                darkMode
                  ? "border-gray-600 bg-gray-700 text-white"
                  : "border-gray-300"
              }`}
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option value="all">All categories</option>
              {categories?.map((category: any, index: any) => (
                <option key={index} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="md:w-44">
            <label
              className={`block text-xs ${
                darkMode ? "text-gray-400" : "text-gray-500"
              }`}
            >
              Items per page
            </label>
            <select
              className={`mt-1 w-full rounded-lg border px-3 py-2 text-sm focus:border-blue-500 ${
                darkMode
                  ? "border-gray-600 bg-gray-700 text-white"
                  : "border-gray-200 bg-white"
              }`}
              value={perPage}
              onChange={(e) => setPerPage(Number(e.target.value))}
            >
              <option value="6">6</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="12">12</option>
            </select>
          </div>
        </div>
      </div>
      {filteredPostsPaginated.length > 0 ? (
        <>
          <div
            className={`text-sm text-end mt-7 ${
              darkMode ? "text-gray-400" : "text-gray-500"
            }`}
          >
            ({filteredPosts.length}) Result
          </div>
          <div className="zoomBody grid grid-cols-1 md:grid-cols-3 gap-3">
            {filteredPostsPaginated.map((post, index) => (
              <div
                key={index}
                className={`group cursor-pointer flex flex-col gap-2 border rounded-lg p-5 transition-all hover:-translate-y-0.5 hover:shadow z-0 ${
                  darkMode
                    ? "bg-gray-800 border-gray-700"
                    : "bg-white border-gray-300"
                }`}
                onClick={() => navigate("/post-details/" + post.id)}
              >
                {post.image ? (
                  <img
                    src={`${Api}/uploads/${post.image}`}
                    alt="Not exist image"
                    className="w-full h-40 rounded-lg transition-all hover:rotate-[2.5deg]"
                  />
                ) : (
                  <div
                    className={`flex justify-center items-center w-full h-40 border p-3 rounded-lg ${
                      darkMode
                        ? "border-gray-700 text-gray-400"
                        : "border-gray-200"
                    }`}
                  >
                    Not exist image
                  </div>
                )}
                <div className="flex justify-between mt-2">
                  <span
                    className={`transition-all ${
                      darkMode
                        ? "text-white group-hover:text-blue-400"
                        : "group-hover:text-blue-700"
                    }`}
                  >
                    {post.title}
                  </span>
                </div>
                <span
                  className={`text-sm ${
                    darkMode ? "text-gray-400" : "text-gray-600"
                  }`}
                >
                  {post.content}
                </span>
                <Category categoryId={post.category_id} />
                <Tags tags={post.tags} />
                <span
                  className={`text-xs ${
                    darkMode ? "text-gray-500" : "text-gray-400"
                  }`}
                >
                  {new Date(post.created_at).toLocaleDateString()}
                </span>
              </div>
            ))}
          </div>
          <Pagination
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
            totalPages={totalPages}
          />
        </>
      ) : (
        <div
          className={`rounded-2xl border border-dashed p-10 text-center ${
            darkMode
              ? "border-gray-700 bg-gray-800"
              : "border-gray-300 bg-white"
          }`}
        >
          <div
            className={`flex justify-center items-center mx-auto h-12 w-12 rounded-xl ${
              darkMode
                ? "bg-gray-700 text-gray-300"
                : "bg-gray-100 text-gray-500"
            }`}
          >
            —
          </div>
          <h3
            className={`text-lg font-semibold mt-4 ${
              darkMode ? "text-gray-100" : "text-gray-900"
            }`}
          >
            No posts published yet
          </h3>
          <p
            className={`mt-1 text-sm ${
              darkMode ? "text-gray-400" : "text-gray-600"
            }`}
          >
            New content will be added soon.
          </p>
        </div>
      )}
    </div>
  );
};

export default MainBody;
