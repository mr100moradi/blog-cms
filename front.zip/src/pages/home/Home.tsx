import Footer from "../../components/footer/Footer";
import MainBody from "./MainBody";
import HomeHeader from "../../components/home-header/HomeHeader";
import "./Home.css";
import Cookies from "universal-cookie";
import { useEffect, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { MyContext } from "../admin/MyContext";

const Home = () => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { darkMode } = context;

  // get token from cookies
  const cookies = new Cookies();
  const token = cookies.get("TOKEN");

  const navigate = useNavigate();

  useEffect(() => {
    if (!token) {
      navigate("/login");
    }
  });

  return (
    <div className={darkMode ? 'dark' : ''}>
      <HomeHeader />

      <main className={`px-4 md:px-72 py-8 ${darkMode ? 'bg-gray-900' : 'bg-gray-50'}`}>
        <MainBody />
      </main>

      <Footer />
    </div>
  );
};

export default Home;
