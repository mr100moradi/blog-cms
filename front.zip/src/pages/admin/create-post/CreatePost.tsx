import "./CreatePost.css";
import MainBody from "./MainBody";
import AdminLayout from "../../../layouts/AdminLayout";

const CreatePost = () => {

  return (
    <AdminLayout mainBody={<MainBody />} />
  );
};

export default CreatePost;
