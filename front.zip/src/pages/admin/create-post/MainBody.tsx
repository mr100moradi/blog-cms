import { useContext, useEffect, useState } from "react";
import axios from "axios";
import Api from "../../../utils/Api";
import { Link, useNavigate } from "react-router-dom";
import { MyContext } from "../MyContext";
import "./MainBody.css";
import toast from "react-hot-toast";

const MainBody = (props: any) => {
  // get context
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { setCountPublished, setCountDraft, darkMode } = context;

  const navigate = useNavigate();

  // content states
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [tagsInput, setTagsInput] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const [categoryId, setCategoryId] = useState("");
  const [status, setStatus] = useState("published");
  const [image, setImage] = useState("");

  const [categories, setCategories] = useState([]);

  // get categories
  const getCategories = async () => {
    const config = {
      method: "GET",
      url: `${Api}/category`,
    };
    await axios(config)
      .then((result) => {
        // console.log(result.data);
        setCategories(result.data);
      })
      .catch((error) => console.log(error));
  };

  // get count publisged posts
  const getCountPublished = async () => {
    const config = {
      method: "GET",
      url: `${Api}/post/countPublished`,
    };
    await axios(config)
      .then((result) => {
        setCountPublished(result.data[0].count_published);
      })
      .catch((error) => console.log(error));
  };

  // get count draft posts
  const getCountDraft = async () => {
    const config = {
      method: "GET",
      url: `${Api}/post/countDraft`,
    };
    await axios(config)
      .then((result) => {
        setCountDraft(result.data[0].count_draft);
      })
      .catch((error) => console.log(error));
  };

  // handle submit
  const handleSubmit = async (e: any) => {
    e.preventDefault();

    // console.log(image);
    const config = {
      method: "POST",
      headers: { "Content-Type": "multipart/form-data" },
      url: `${Api}/post/add`,
      data: {
        title,
        content,
        tags,
        categoryId: parseInt(categoryId),
        status,
        image,
      },
    };

    await axios(config)
      .then((result) => {
        console.log(result.data);
        getCountPublished();
        getCountDraft();
        navigate("/admin/posts");
        toast.success(<div>Post created successfully</div>);
      })
      .catch((error) => {
        console.log(error);
        toast.error(<div>{error.response.statusText}</div>);
      });
  };

  useEffect(() => {
    getCategories();
  }, []);

  return (
    <div className="zoomBody w-full flex flex-col px-7 space-y-5">
      <div className="flex justify-between items-center">
        <div>
          <h3
            className={`capitalize font-bold ${
              darkMode ? "text-white" : "text-gray-900"
            }`}
          >
            Create new post
          </h3>
          <p
            className={`text-sm ${
              darkMode ? "text-gray-400" : "text-gray-700"
            }`}
          >
            Enter title, content and tags.
          </p>
        </div>
        <Link
          to="/admin/posts"
          className={`cursor-pointer border rounded-lg px-2 py-1 transition-all ${
            darkMode
              ? "border-gray-600 hover:bg-gray-700 text-gray-300"
              : "border-gray-300 hover:bg-gray-100"
          }`}
        >
          Back to posts
        </Link>
      </div>
      <div
        className={`rounded-xl border p-6 shadow-sm ${
          darkMode ? "border-gray-700 bg-gray-800" : "border-gray-200 bg-white"
        }`}
      >
        <form onSubmit={(e) => handleSubmit(e)} className="space-y-4">
          <div>
            <label
              className={`mb-1 block text-sm font-medium ${
                darkMode ? "text-gray-300" : "text-gray-900"
              }`}
            >
              Title
            </label>
            <input
              className={`w-full border rounded-lg p-2 text-sm focus:border-blue-500 ${
                darkMode
                  ? "border-gray-600 bg-gray-700 text-white placeholder-gray-400"
                  : "border-gray-300"
              }`}
              placeholder="e.g. My first post"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>
          <div>
            <label
              className={`mb-1 block text-sm font-medium ${
                darkMode ? "text-gray-300" : "text-gray-900"
              }`}
            >
              Content
            </label>
            <input
              className={`w-full border rounded-lg p-2 text-sm focus:border-blue-500 ${
                darkMode
                  ? "border-gray-600 bg-gray-700 text-white placeholder-gray-400"
                  : "border-gray-300"
              }`}
              placeholder="Write your post..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
            />
          </div>
          <div>
            <label
              className={`mb-1 block text-sm font-medium ${
                darkMode ? "text-gray-300" : "text-gray-900"
              }`}
            >
              Tags
            </label>
            <input
              className={`w-full border rounded-lg p-2 text-sm focus:border-blue-500 ${
                darkMode
                  ? "border-gray-600 bg-gray-700 text-white placeholder-gray-400"
                  : "border-gray-300"
              }`}
              placeholder="e.g. react, ui"
              value={tagsInput}
              onChange={(e) => {
                const text = e.target.value;
                setTagsInput(text);

                let arrayValue = text.split(",");
                arrayValue = arrayValue.filter(
                  (item) => item.toString().length > 0
                );
                setTags(arrayValue);
              }}
            />
          </div>
          <div>
            <label
              className={`mb-1 block text-sm font-medium ${
                darkMode ? "text-gray-300" : "text-gray-900"
              }`}
            >
              Category
            </label>
            <select
              className={`w-full border rounded-lg p-2 text-sm focus:border-blue-500 ${
                darkMode
                  ? "border-gray-600 bg-gray-700 text-white"
                  : "border-gray-300"
              }`}
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
            >
              <option value="0">select category</option>

              {categories.map((category, index) => (
                <option key={index} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
            <p
              className={`mt-1 text-xs ${
                darkMode ? "text-gray-400" : "text-gray-500"
              }`}
            >
              Tip: add categories on the Categories page.
            </p>
          </div>
          <div>
            <label
              className={`mb-1 block text-sm font-medium ${
                darkMode ? "text-gray-300" : "text-gray-900"
              }`}
            >
              Status
            </label>
            <select
              className={`w-full border rounded-lg p-2 text-sm focus:border-blue-500 ${
                darkMode
                  ? "border-gray-600 bg-gray-700 text-white"
                  : "border-gray-300"
              }`}
              value={status}
              onChange={(e) => setStatus(e.target.value)}
            >
              <option value="published">Published</option>
              <option value="draft">Draft</option>
            </select>
          </div>
          <div>
            <label
              className={`mb-1 block text-sm font-medium ${
                darkMode ? "text-gray-300" : "text-gray-900"
              }`}
            >
              Cover image
            </label>
            <div className="flex items-center gap-2">
              <input
                accept="image/*"
                className={`cursor-pointer w-full border rounded-lg p-2 text-sm focus:border-blue-500 ${
                  darkMode
                    ? "border-gray-600 bg-gray-700 text-white"
                    : "border-gray-300"
                }`}
                type="file"
                name="image"
                onChange={(e: any) => setImage(e.target.files[0])}
              />
            </div>
            <p
              className={`mt-1 text-xs ${
                darkMode ? "text-gray-400" : "text-gray-500"
              }`}
            >
              Upload an image; it will be stored under postImg.
            </p>
          </div>
          <details
            className={`rounded-lg border p-3 text-sm open:pb-4 ${
              darkMode ? "border-gray-700" : "border-gray-200"
            }`}
          >
            <summary
              className={`cursor-pointer select-none font-medium ${
                darkMode ? "text-gray-300" : "text-gray-900"
              }`}
            >
              Preview
            </summary>
            <div
              className={`mt-3 max-w-none ${
                darkMode ? "text-gray-300" : "text-gray-900"
              }`}
            >
              <p>
                <em>Nothing to preview yet.</em>
              </p>
            </div>
          </details>
          <div className="flex justify-end gap-2 pt-2">
            <Link
              to="/admin/posts"
              className={`cursor-pointer text-sm border rounded-lg px-2 py-1 transition-all ${
                darkMode
                  ? "border-gray-600 hover:bg-gray-700 text-gray-300"
                  : "border-gray-300 hover:bg-gray-100"
              }`}
            >
              Cancel
            </Link>
            <button
              type="submit"
              className="cursor-pointer text-sm bg-gradient-to-br from-blue-500 to-blue-700 hover:to-blue-900 text-white px-3 py-1 rounded-lg"
            >
              Create post
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default MainBody;
