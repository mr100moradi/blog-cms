import axios from "axios";
import "./Category.css";
import Api from "../../../utils/Api";
import { useEffect, useState, useContext } from "react";
import { MyContext } from "../MyContext";

const Category = (props: any) => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { darkMode } = context;
  const [category, setCategory] = useState({});

  const getCategory = async () => {
    const config = {
      method: "GET",
      url: `${Api}/category/single/${props.categoryId}`,
    };

    await axios(config)
      .then((result) => {
        setCategory(result.data);
      })
      .catch((error) => console.log(error));
  };

  useEffect(() => {
    getCategory();
  }, [props.categoryId]);

  return (
    <div>
      <button className={`cursor-pointer transition-all text-xs border rounded-2xl px-2 py-1 ${
        darkMode 
          ? 'bg-gray-700 text-gray-300 border-gray-600' 
          : 'bg-white text-gray-600 border-gray-300'
      }`}>
        {category.name}
      </button>
    </div>
  );
};

export default Category;
