import { useContext, useEffect, useState } from "react";
import "./Posts.css";
import Api from "../../../utils/Api";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEdit, faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import Tags from "./Tags";
import { Link, useNavigate, useParams } from "react-router-dom";
import Category from "./Category";
import Pagination from "./Pagination";
import { PlusIcon } from "@heroicons/react/24/outline";
import toast from "react-hot-toast";
import { MyContext } from "../MyContext";

const Posts = () => {
  // get context
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { setCountPublished, darkMode } = context;

  const navigate = useNavigate();

  // content states
  const [categories, setCategories] = useState([]);
  const [posts, setPosts] = useState([]);

  // filter states
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  const [perPage, setPerPage] = useState(6);

  // pagination states
  const [currentPage, setCurrentPage] = useState(1);

  // filter posts
  const filteredPosts = posts?.filter((post: any) => {
    const searchLower = search.toLowerCase();

    const matchesPublished = post.status === "published";

    const matchesSearch =
      post.title.toLowerCase().includes(searchLower) ||
      post.content.toLowerCase().includes(searchLower);

    const matchesPost =
      category === "all" || post.category_id.toString() === category;

    return matchesPublished && matchesSearch && matchesPost;
  });

  // pagination posts
  const totalPages = Math.ceil(filteredPosts.length / perPage);
  const filteredPostsPaginated = filteredPosts.slice(
    (currentPage - 1) * perPage,
    currentPage * perPage
  );

  // get categories
  const getCategories = async () => {
    const config = {
      method: "GET",
      url: `${Api}/category`,
    };
    await axios(config)
      .then((result) => {
        // console.log(result.data);
        setCategories(result.data);
      })
      .catch((error) => console.log(error));
  };

  // get posts
  const getPosts = async () => {
    const config = {
      method: "GET",
      url: `${Api}/post`,
    };
    await axios(config)
      .then((result) => {
        // console.log(result.data);
        setPosts(result.data);
      })
      .catch((error) => console.log(error));
  };

  // get count publisged posts
  const getCountPublished = async () => {
    const config = {
      method: "GET",
      url: `${Api}/post/countPublished`,
    };
    await axios(config)
      .then((result) => {
        setCountPublished(result.data[0].count_published);
      })
      .catch((error) => console.log(error));
  };

  // handle delete
  const handleDelete = async (id: any) => {
    let comments = [];

    // get comments by post id
    const configCommentsByPostId = {
      method: "GET",
      url: `${Api}/comment/commentsByPostId/${id}`,
    };
    await axios(configCommentsByPostId)
      .then((result) => {
        comments = result.data;
      })
      .catch((error) => {
        console.log(error);
      });

    // check comments length
    if (comments.length > 0) {
      return toast.error(
        <div>This post has comments and will can not deleted!</div>,
        {
          duration: 8000,
        }
      );
    }

    // delete post
    const configPost = {
      method: "DELETE",
      url: `${Api}/post/delete/${id}`,
    };
    await axios(configPost)
      .then((result) => {
        // console.log(result.data);
        getPosts();
        getCountPublished();
        toast.success(<div>Post deleted successfully</div>);
      })
      .catch((error) => {
        console.log(error);
        toast.error(<div>{error.response.statusText}</div>);
      });
  };

  useEffect(() => {
    getCategories();
    getPosts();
  }, []);

  return (
    <div className="zoomBody w-full flex flex-col px-7 space-y-5">
      <div className="flex justify-between items-center">
        <div className="">
          <h3 className={`capitalize font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>Posts</h3>
          <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-700'}`}>Your posts will appear here.</p>
        </div>
        <button
          className="cursor-pointer flex items-center gap-1 bg-gradient-to-br from-blue-500 to-blue-700 hover:to-blue-900 text-white px-2 py-1 rounded-lg"
          onClick={() => navigate("/admin/create-post")}
        >
          <PlusIcon className="w-5 h-5" />
          New Post
        </button>
      </div>
      <div className="flex justify-between items-center flex-wrap gap-2">
        <div className="flex items-center flex-wrap gap-2">
          <input
            className={`w-auto border rounded-lg p-2 text-sm focus:border-blue-500 ${
              darkMode 
                ? 'border-gray-600 bg-gray-700 text-white placeholder-gray-400' 
                : 'border-gray-300'
            }`}
            placeholder="Search posts..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <select
            className={`w-auto border text-sm rounded-lg p-2 focus:border-blue-500 ${
              darkMode 
                ? 'border-gray-600 bg-gray-700 text-white' 
                : 'border-gray-300'
            }`}
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="all">All categories</option>
            {categories?.map((category: any, index: any) => (
              <option key={index} value={category.id}>
                {category.name}
              </option>
            ))}
          </select>
          <select
            className={`w-auto border text-sm rounded-lg p-2 focus:border-blue-500 ${
              darkMode 
                ? 'border-gray-600 bg-gray-700 text-white' 
                : 'border-gray-300'
            }`}
            value={perPage}
            onChange={(e) => setPerPage(Number(e.target.value))}
          >
            <option value="6">6 / page</option>
            <option value="9">9 / page</option>
            <option value="12">12 / page</option>
            <option value="18">18 / page</option>
          </select>
        </div>
        <span className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
          ({filteredPosts.length}) Result
        </span>
      </div>
      {filteredPostsPaginated.length > 0 ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {filteredPostsPaginated.map((post, index) => (
              <div
                key={index}
                className={`group cursor-pointer flex flex-col gap-2 border rounded-lg p-5 transition-all hover:-translate-y-0.5 hover:shadow ${
                  darkMode 
                    ? 'bg-gray-800 border-gray-700' 
                    : 'bg-white border-gray-300'
                }`}
              >
                {post.image ? (
                  <img
                    src={`${Api}/uploads/${post.image}`}
                    alt="Not exist image"
                    className="w-full h-40 rounded-lg transition-all hover:rotate-[2.5deg]"
                  />
                ) : (
                  <div className={`flex justify-center items-center w-full h-40 border p-3 rounded-lg ${
                    darkMode 
                      ? 'border-gray-700 text-gray-400' 
                      : 'border-gray-200 text-gray-600'
                  }`}>
                    Not exist image
                  </div>
                )}
                <div className="flex justify-between mt-2">
                  <span className={`transition-all ${
                    darkMode 
                      ? 'text-white group-hover:text-blue-400' 
                      : 'group-hover:text-blue-700'
                  }`}>
                    {post.title}
                  </span>
                  <div className="flex items-center gap-1">
                    <Link
                      to={"/admin/edit-post/" + post.id}
                      className={`cursor-pointer border rounded-md p-1.5 text-sm transition-all ${
                        darkMode 
                          ? 'border-gray-600 hover:bg-gray-700 text-gray-300' 
                          : 'border-gray-300 hover:bg-gray-100'
                      }`}
                    >
                      <FontAwesomeIcon icon={faEdit} className="" />
                    </Link>
                    <button
                      className="cursor-pointer flex justify-center items-center w-8 h-8 rounded-md p-1 text-white text-xs transition-all bg-red-600 hover:bg-red-700"
                      onClick={() => handleDelete(post.id)}
                    >
                      <FontAwesomeIcon icon={faTrashAlt} className="" />
                    </button>
                  </div>
                </div>
                <span className={`text-sm ${
                  darkMode ? 'text-gray-400' : 'text-gray-600'
                }`}>{post.content}</span>
                <Category
                  categoryId={post.category_id}
                  setCategory={setCategory}
                />
                <Tags tags={post.tags} />
                <span className={`text-xs ${
                  darkMode ? 'text-gray-500' : 'text-gray-400'
                }`}>
                  {new Date(post.created_at).toLocaleDateString()}
                </span>
              </div>
            ))}
          </div>
          <Pagination
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
            totalPages={totalPages}
          />
        </>
      ) : (
        <div className="space-y-3">
          <div className="rounded-2xl border border-dashed border-gray-300 bg-white p-10 text-center dark:border-gray-700 dark:bg-gray-900">
            <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-300"></div>
            <h3 className="text-lg font-semibold dark:text-gray-100">
              No posts yet
            </h3>
            <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
              Click New Post to create your first post.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default Posts;
