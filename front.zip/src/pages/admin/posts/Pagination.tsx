import "./Pagination.css";
import { useContext } from "react";
import { MyContext } from "../MyContext";

const Pagination = (props: any) => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { darkMode } = context;

  return (
    <div className="text-center mt-8">
      <button
        disabled={props.currentPage === 1}
        onClick={() => props.setCurrentPage((prev) => prev - 1)}
        className={`cursor-pointer rounded-xl border px-4 py-2 mr-3 text-sm font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
          darkMode 
            ? 'border-gray-600 bg-gray-800 text-gray-300 hover:border-gray-500 hover:text-white' 
            : 'border-slate-200 bg-white text-slate-600 hover:border-gray-400 hover:text-gray-600'
        }`}
      >
        Previous
      </button>

      {[...Array(props.totalPages)].map((x: any, i: any) =>
        i + 1 === props.currentPage ? (
          <button
            key={i}
            className="cursor-pointer rounded-xl px-4 py-2 mx-1 text-sm font-medium transition-all bg-gradient-to-r from-gray-500 to-gray-700 text-white"
            onClick={() => props.setCurrentPage(i + 1)}
          >
            {i + 1}
          </button>
        ) : (
          <button
            key={i}
            className={`cursor-pointer rounded-xl px-4 py-2 mx-1 text-sm font-medium transition-all border ${
              darkMode 
                ? 'border-gray-600 bg-gray-800 text-gray-300 hover:border-gray-500 hover:text-white' 
                : 'border-slate-200 bg-white text-slate-600 hover:border-gray-400 hover:text-gray-600'
            }`}
            onClick={() => props.setCurrentPage(i + 1)}
          >
            {i + 1}
          </button>
        )
      )}

      <button
        disabled={props.currentPage === props.totalPages}
        onClick={() => props.setCurrentPage((prev) => prev + 1)}
        className={`cursor-pointer rounded-xl border px-4 py-2 ml-3 text-sm font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
          darkMode 
            ? 'border-gray-600 bg-gray-800 text-gray-300 hover:border-gray-500 hover:text-white' 
            : 'border-slate-200 bg-white text-slate-600 hover:border-gray-400 hover:text-gray-600'
        }`}
      >
        Next
      </button>
    </div>
  );
};

export default Pagination;
