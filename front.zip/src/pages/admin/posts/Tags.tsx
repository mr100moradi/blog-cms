import "./Tags.css";
import { useContext } from "react";
import { MyContext } from "../MyContext";

const Tags = (props: any) => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { darkMode } = context;

  return (
    <>
      {props.tags?.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {props.tags?.map((tag: any, index:any) => (
            <span
              key={index}
              className={`text-xs border rounded-2xl px-2 py-1 transition-all ${
                darkMode 
                  ? 'bg-gray-700 text-gray-300 border-gray-600' 
                  : 'bg-white text-gray-600 border-gray-300'
              }`}
            >
              {tag}
            </span>
          ))}
        </div>
      )}
    </>
  );
};

export default Tags;
