import AdminLayout from "../../../layouts/AdminLayout";
import MainBody from "./MainBody";
import "./EditDraft.css";
import { useParams } from "react-router-dom";

const EditDraft = () => {
  
  const { id } = useParams();

  return <AdminLayout mainBody={<MainBody postId={id} />} />;
};

export default EditDraft;
