import AdminLayout from "../../../layouts/AdminLayout";
import MainBody from "./MainBody";
import "./Comments.css";

const Comments = () => {
  return <AdminLayout mainBody={<MainBody />} />;
};

export default Comments;
