import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEdit, faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import { useContext, useEffect, useState } from "react";
import Api from "../../../utils/Api";
import axios from "axios";
import { Link } from "react-router-dom";
import "./Comment.css";
import { MyContext } from "../MyContext";
import toast from "react-hot-toast";

const Comment = (props: any) => {
  // get context
  const context = useContext(MyContext);
  if (!context) return null;
  const { setCountComments, darkMode } = context;

  // content states
  const [post, setPost] = useState({});

  // get post
  const getPost = async () => {
    const config = {
      method: "GET",
      url: `${Api}/post/single/${props.commentSingle.post_id}`,
    };
    await axios(config)
      .then((result: any) => {
        setPost(result.data);
      })
      .catch((error: any) => console.log(error));
  };

  // get count comments
  const getCountComments = async () => {
    const config = {
      method: "GET",
      url: `${Api}/comment/countComments`,
    };
    await axios(config)
      .then((result) => {
        setCountComments(result.data[0].count_comments);
      })
      .catch((error) => console.log(error));
  };

  // handle delete
  const handleDelete = async (id: any) => {
    console.log(id);
    const config = {
      method: "DELETE",
      url: `${Api}/comment/delete/${id}`,
    };
    await axios(config)
      .then((result) => {
        // console.log(result.data);
        props.getComments();
        getCountComments();
        toast.success(<div>Comment deleted successfully</div>);
      })
      .catch((error) => {
        console.log(error);
        toast.error(<div>{error.response.statusText}</div>);
      });
  };

  useEffect(() => {
    getPost();
  }, [props.commentSingle]);

  return (
    <>
      <div
        className={`flex items-start justify-between gap-4 rounded-lg border p-4 ${
          darkMode ? "border-gray-700 bg-gray-800" : "border-gray-200 bg-white"
        }`}
      >
        {post.image ? (
          <div className=" rounded-lg overflow-hidden">
            <img
              src={`${Api}/uploads/${post.image}`}
              alt="Not exist image"
              className="w-20 h-14 transition-all duration-300 hover:scale-105"
            />
          </div>
        ) : (
          <div
            className={`flex justify-center items-center w-36 h-14 border p-3 rounded-lg ${
              darkMode
                ? "border-gray-700 text-gray-400"
                : "border-gray-200 text-gray-600"
            }`}
          >
            Not exist image
          </div>
        )}
        <div className="min-w-0 flex-1">
          <div
            className={`flex flex-wrap items-center gap-3 text-xs ${
              darkMode ? "text-gray-400" : "text-gray-500"
            }`}
          >
            <span className="truncate">Post: {post.title}</span>
            <span className="truncate">By: {props.commentSingle.name}</span>
            <span>
              {new Date(props.commentSingle.created_at).toLocaleString()}
            </span>
          </div>
          <p
            className={`mt-1 text-sm ${
              darkMode ? "text-gray-200" : "text-gray-800"
            }`}
          >
            {props.commentSingle.comment}
          </p>
        </div>
        <div className="flex items-center gap-1">
          <Link
            to={"/admin/edit-comment/" + props.commentSingle.id}
            className={`cursor-pointer border rounded-md p-1.5 text-sm transition-all ${
              darkMode
                ? "border-gray-600 hover:bg-gray-700 text-gray-300"
                : "border-gray-300 hover:bg-gray-100"
            }`}
          >
            <FontAwesomeIcon icon={faEdit} className="" />
          </Link>
          <button
            className="cursor-pointer flex justify-center items-center w-8 h-8 rounded-md p-1 text-white text-xs transition-all bg-red-600 hover:bg-red-700"
            onClick={() => handleDelete(props.commentSingle.id)}
          >
            <FontAwesomeIcon icon={faTrashAlt} className="" />
          </button>
        </div>
      </div>
    </>
  );
};

export default Comment;
