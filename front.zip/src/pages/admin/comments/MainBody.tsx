import { useEffect, useState, useContext } from "react";
import axios from "axios";
import Api from "../../../utils/Api";
import Comment from "./Comment";
import Pagination from "../posts/Pagination";
import "./MainBody.css";
import { MyContext } from "../MyContext";

const MainBody = () => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { darkMode } = context;

  // content states
  const [posts, setPosts] = useState([]);
  const [comments, setComments] = useState([]);

  // filter states
  const [search, setSearch] = useState("");
  const [post, setPost] = useState("all");
  const [perPage, setPerPage] = useState(10);

  // pagination states
  const [currentPage, setCurrentPage] = useState(1);

  // filter comments
  const filteredComments = comments?.filter((comment: any) => {
    const searchLower = search.toLowerCase();

    const matchesSearch =
      comment.name.toLowerCase().includes(searchLower) ||
      comment.comment.toLowerCase().includes(searchLower);

    const matchesPost = post === "all" || comment.post_id.toString() === post;

    return matchesSearch && matchesPost;
  });

  // pagination comments
  const totalPages = Math.ceil(filteredComments.length / perPage);
  const filteredCommentsPaginated = filteredComments.slice(
    (currentPage - 1) * perPage,
    currentPage * perPage
  );

  const getPosts = async () => {
    const config = {
      method: "GET",
      url: `${Api}/post`,
    };
    await axios(config)
      .then((result: any) => {
        setPosts(result.data);
      })
      .catch((error: any) => console.log(error));
  };

  const getComments = async () => {
    const config = {
      method: "GET",
      url: `${Api}/comment`,
    };
    await axios(config)
      .then((result: any) => {
        setComments(result.data);
      })
      .catch((error: any) => console.log(error));
  };

  useEffect(() => {
    getPosts();
    getComments();
  }, []);

  return (
    <div className="zoomBody w-full flex flex-col px-7 space-y-5">
      <div className="flex flex-col">
        <span className={`capitalize font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>Comments</span>
        <span className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-700'}`}>
          Your comments will appear here.
        </span>
      </div>
      <div className="flex justify-between items-center flex-wrap gap-2">
        <div className="flex items-center flex-wrap gap-2">
          <input
            className={`w-auto border rounded-lg p-2 text-sm focus:border-blue-500 ${
              darkMode 
                ? 'border-gray-600 bg-gray-700 text-white placeholder-gray-400' 
                : 'border-gray-300'
            }`}
            placeholder="Search comments..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <select
            className={`w-auto border rounded-lg p-2 text-sm focus:border-blue-500 ${
              darkMode 
                ? 'border-gray-600 bg-gray-700 text-white' 
                : 'border-gray-300'
            }`}
            value={post}
            onChange={(e) => setPost(e.target.value.toString())}
          >
            <option value="all">All posts</option>
            {posts?.map((post, index) => (
              <option key={index} value={post.id}>
                {post.title}
              </option>
            ))}
          </select>
          <select
            className={`w-auto border rounded-lg p-2 text-sm focus:border-blue-500 ${
              darkMode 
                ? 'border-gray-600 bg-gray-700 text-white' 
                : 'border-gray-300'
            }`}
            value={perPage}
            onChange={(e) => setPerPage(Number(e.target.value))}
          >
            <option value="10">10 / page</option>
            <option value="20">20 / page</option>
            <option value="30">30 / page</option>
          </select>
        </div>
        <span className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
          ({filteredCommentsPaginated.length}) Result
        </span>
      </div>
      {filteredCommentsPaginated.length > 0 ? (
        <>
          {filteredCommentsPaginated.map((comment: any, index: any) => (
            <Comment
              key={index}
              commentSingle={comment}
              getComments={getComments}
            />
          ))}
          <Pagination
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
            totalPages={totalPages}
          />
        </>
      ) : (
        <div className="space-y-3">
          <div className={`rounded-2xl border border-dashed p-10 text-center ${
            darkMode 
              ? 'border-gray-700 bg-gray-800' 
              : 'border-gray-300 bg-white'
          }`}>
            <div className={`mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl ${
              darkMode 
                ? 'bg-gray-700 text-gray-300' 
                : 'bg-gray-100 text-gray-500'
            }`}>
              —
            </div>
            <h3 className={`text-lg font-semibold ${
              darkMode ? 'text-gray-100' : 'text-gray-900'
            }`}>
              No comments yet
            </h3>
          </div>
        </div>
      )}
    </div>
  );
};

export default MainBody;
