import { useContext, useEffect, useState } from "react";
import "./MainBody.css";
import Api from "../../../utils/Api";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEdit, faPlus, faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import NewCategoryModal from "./NewCategoryModal";
import { MyContext } from "../MyContext";
import toast from "react-hot-toast";

const MainBody = () => {
  // get context
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { setCountCategories, darkMode } = context;

  // modal state
  const [openModal, setOpenModal] = useState(false);

  // content states
  const [categories, setCategories] = useState([]);
  const [category, setCategory] = useState(null);

  // operation states
  const [operation, setOperation] = useState("add");

  // get categories
  const getCategories = async () => {
    const config = {
      method: "GET",
      url: `${Api}/category`,
    };
    await axios(config)
      .then((result) => {
        // console.log(result.data);
        setCategories(result.data);
      })
      .catch((error) => console.log(error));
  };

  // get count categories
  const getCountCategories = async () => {
    const config = {
      method: "GET",
      url: `${Api}/category/countCategories`,
    };
    await axios(config)
      .then((result) => {
        setCountCategories(result.data[0].count_categories);
      })
      .catch((error) => console.log(error));
  };

  // handle delete
  const handleDelete = async (id: any) => {
    const config = {
      method: "DELETE",
      url: `${Api}/category/delete/${id}`,
    };
    await axios(config)
      .then((result) => {
        // console.log(result.data);
        getCategories();
        getCountCategories();
        toast.success(<div>Category deleted successfully</div>);
      })
      .catch((error) => {
        console.log(error);
        toast.error(<div>{error.response.statusText}</div>);
      });
  };

  useEffect(() => {
    getCategories();
  }, []);

  return (
    <>
      <div className="zoomBody w-full h-dvh px-7">
        <div className="flex flex-col space-y-5">
          <div className="flex justify-between items-center">
            <div>
              <h3
                className={`capitalize font-bold ${
                  darkMode ? "text-white" : "text-gray-900"
                }`}
              >
                Categories
              </h3>
              <p
                className={`text-sm ${
                  darkMode ? "text-gray-400" : "text-gray-700"
                }`}
              >
                Your categories will appear here.
              </p>
            </div>
            <button
              className="cursor-pointer flex justify-center items-center gap-1 text-sm bg-gradient-to-br from-blue-500 to-blue-700 hover:to-blue-900 text-white px-2 py-2 rounded-lg"
              onClick={() => {
                setOperation("add");
                setCategory(null);
                setOpenModal(true);
              }}
            >
              <FontAwesomeIcon icon={faPlus} className="" />
              Add category
            </button>
          </div>

          <div className="flex items-center gap-1 flex-wrap">
            {categories.length > 0 ? (
              categories.map((category, index) => (
                <div
                  key={index}
                  className={`flex items-center gap-1 rounded-full border px-1.5 py-1 ${
                    darkMode
                      ? "border-gray-700 text-gray-200"
                      : "border-gray-200 text-gray-700"
                  }`}
                >
                  <button
                    className={`cursor-pointer px-2 text-sm hover:underline ${
                      darkMode ? "hover:text-blue-300" : ""
                    }`}
                    onClick={() => {
                      setOperation("update");
                      setCategory(category);
                      setOpenModal(true);
                    }}
                  >
                    {category.name}
                  </button>
                  <button
                    className={`cursor-pointer border rounded-md p-1.5 text-sm transition-all ${
                      darkMode
                        ? "border-gray-600 hover:bg-gray-700 text-gray-300"
                        : "border-gray-300 hover:bg-gray-100"
                    }`}
                    aria-label="Rename"
                    onClick={() => {
                      setOperation("update");
                      setCategory(category);
                      setOpenModal(true);
                    }}
                  >
                    <FontAwesomeIcon icon={faEdit} />
                  </button>

                  <button
                    className="cursor-pointer flex justify-center items-center w-8 h-8 rounded-md p-1 text-white text-xs transition-all bg-red-600 hover:bg-red-700"
                    aria-label="Delete"
                    onClick={() => {
                      handleDelete(category.id);
                    }}
                  >
                    <FontAwesomeIcon icon={faTrashAlt} />
                  </button>
                </div>
              ))
            ) : (
              <div className="w-full space-y-3">
                <div
                  className={`rounded-2xl border border-dashed p-10 text-center ${
                    darkMode
                      ? "border-gray-700 bg-gray-800"
                      : "border-gray-300 bg-white"
                  }`}
                >
                  <div
                    className={`mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl ${
                      darkMode
                        ? "bg-gray-700 text-gray-300"
                        : "bg-gray-100 text-gray-500"
                    }`}
                  >
                    —
                  </div>
                  <h3
                    className={`text-lg font-semibold ${
                      darkMode ? "text-gray-100" : "text-gray-900"
                    }`}
                  >
                    No categories yet
                  </h3>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      {openModal && (
        <NewCategoryModal
          setOpenModal={setOpenModal}
          operation={operation}
          category={category}
          getCategories={getCategories}
        />
      )}
    </>
  );
};

export default MainBody;
