import AdminLayout from "../../../layouts/AdminLayout";
import MainBody from "./MainBody";
import "./Categories.css";

const Categories = () => {
  return <AdminLayout mainBody={<MainBody />} />;
};

export default Categories;
