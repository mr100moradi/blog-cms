import { useContext, useState } from "react";
import Api from "../../../utils/Api";
import axios from "axios";
import "./NewCategoryModal.css";
import { MyContext } from "../MyContext";
import toast from "react-hot-toast";

const NewCategoryModal = (props: any) => {
  // get context
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { setCountCategories, darkMode } = context;

  const [name, setName] = useState(props.category?.name ?? "");

  // get count categories
  const getCountCategories = async () => {
    const config = {
      method: "GET",
      url: `${Api}/category/countCategories`,
    };
    await axios(config)
      .then((result) => {
        setCountCategories(result.data[0].count_categories);
      })
      .catch((error) => console.log(error));
  };

  // handle save
  const handleSave = async () => {
    if (name === "") {
      return;
    }

    let config = {};

    if (props.operation === "add") {
      config = {
        method: "POST",
        url: `${Api}/category/add`,
        data: {
          name: name,
        },
      };
    }
    if (props.operation === "update") {
      config = {
        method: "PUT",
        url: `${Api}/category/update/${props.category.id}`,
        data: {
          name: name,
        },
      };
    }

    await axios(config)
      .then((result) => {
        // console.log(result.data);
        props.getCategories();
        props.setOpenModal(false);
        getCountCategories();
        if (props.operation === "add") {
          toast.success(<div>Category created successfully</div>);
        }
        if (props.operation === "update") {
          toast.success(<div>Category updated successfully</div>);
        }
      })
      .catch((error) => {
        console.log(error);
        toast.error(<div>{error.response.statusText}</div>);
      });
  };

  return (
    <div
      className={`absolute top-[25%] left-5 md:left-[25%] w-[90%] md:w-full max-w-md rounded-2xl p-6 shadow-xl z-3 ${
        darkMode ? "bg-gray-900 border border-gray-800" : "bg-white"
      }`}
    >
      <h3
        className={`mb-4 text-lg font-semibold ${
          darkMode ? "text-white" : "text-gray-900"
        }`}
      >
        Add category
      </h3>
      <div
        className={`text-sm ${darkMode ? "text-gray-300" : "text-gray-700"}`}
      >
        <div className="space-y-2">
          <label
            className={`block text-sm font-medium ${
              darkMode ? "text-gray-300" : "text-gray-900"
            }`}
          >
            Name
          </label>
          <input
            className={`w-full border text-sm rounded-lg p-2 focus:border-blue-500 ${
              darkMode
                ? "border-gray-600 bg-gray-800 text-white placeholder-gray-400"
                : "border-gray-300"
            }`}
            placeholder="e.g. tutorials"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => {
              e.key === "Enter" && handleSave();
            }}
          />
        </div>
      </div>
      <div className="mt-6 flex justify-end gap-2">
        <button
          className={`cursor-pointer rounded-lg border px-4 py-2 text-sm transition-all ${
            darkMode
              ? "border-gray-700 bg-gray-800 text-gray-200 hover:bg-gray-700"
              : "border-gray-300 bg-white text-gray-700 hover:bg-gray-50"
          }`}
          onClick={() => {
            props.setOpenModal(false);
          }}
        >
          Cancel
        </button>
        <button
          className="cursor-pointer rounded-lg bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700"
          onClick={() => {
            handleSave();
          }}
        >
          Save
        </button>
      </div>
    </div>
  );
};

export default NewCategoryModal;
