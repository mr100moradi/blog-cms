
import "./Drafts.css";
import AdminLayout from "../../../layouts/AdminLayout";
import MainBody from "./MainBody";

const Drafts = () => {

  return (
      <AdminLayout mainBody={<MainBody />} />
  );
};

export default Drafts;
