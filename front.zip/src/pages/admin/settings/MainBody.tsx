import { useEffect, useState, useContext } from "react";
import "./Settings.css";
import axios from "axios";
import Api from "../../../utils/Api";
import toast from "react-hot-toast";
import { MyContext } from "../MyContext";

const MainBody = () => {
  // get context
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { setCountPublished, setCountDraft, darkMode } = context;
  // content state
  const [posts, setPosts] = useState([]);

  // get posts
  const getPosts = async () => {
    const config = {
      method: "GET",
      url: `${Api}/post`,
    };
    await axios(config)
      .then((result: any) => {
        console.log(result.data);
        setPosts(result.data);
      })
      .catch((error: any) => console.log(error));
  };

  // get count publisged posts
  const getCountPublished = async () => {
    const config = {
      method: "GET",
      url: `${Api}/post/countPublished`,
    };
    await axios(config)
      .then((result) => {
        setCountPublished(result.data[0].count_published);
      })
      .catch((error) => console.log(error));
  };

  // get count draft posts
  const getCountDraft = async () => {
    const config = {
      method: "GET",
      url: `${Api}/post/countDraft`,
    };
    await axios(config)
      .then((result) => {
        setCountDraft(result.data[0].count_draft);
      })
      .catch((error) => console.log(error));
  };

  // delete posts
  const deleteAllPosts = async () => {
    const config = {
      method: "DELETE",
      url: `${Api}/post/deleteAllPosts`,
    };
    await axios(config)
      .then((result: any) => {
        console.log(result.data);
      })
      .catch((error: any) => {
        console.log(error);
      });
  };

  // insert all posts
  const insertAllPosts = async (data: any) => {
    const config = {
      method: "POST",
      url: `${Api}/post/insertAllPosts`,
      data: {
        data,
      },
    };
    await axios(config)
      .then((result: any) => {
        console.log(result.data);
        getCountPublished();
        getCountDraft();
        toast.success(<div>Imported all posts successfully</div>, {
          duration: 8000,
        });
      })
      .catch((error: any) => {
        console.log(error);
        toast.error(<div>{error.response.statusText}</div>, {
          duration: 8000,
        });
      });
  };

  // export posts
  const handleExport = () => {
    const blob = new Blob([JSON.stringify(posts)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "blog-posts.json";
    a.click();
    URL.revokeObjectURL(url);
    toast.success(<div>Exported all posts as JSON successfully</div>, {
      duration: 8000,
    });
  };

  // import posts
  const handleImport = async (e: any) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);

      if (posts.length > 0) {
        return toast.error(<div>Posts is not empty </div>, {
          duration: 8000,
        });
      }

      if (!Array.isArray(data)) {
        return toast.error(<div>JSON file is not valid </div>, {
          duration: 8000,
        });
      }

      deleteAllPosts();
      insertAllPosts(data);
    } catch (err) {
      toast.error(<div>Import failed: invalid JSON</div>, {
        duration: 8000,
      });
    } finally {
      e.target.value = "";
    }
  };

  return (
    <div className="zoomBody w-full h-dvh px-7 space-y-5">
      <div>
        <h3
          className={`capitalize font-bold ${
            darkMode ? "text-white" : "text-gray-900"
          }`}
        >
          Settings
        </h3>
        <p className={darkMode ? "text-gray-400" : "text-gray-700"}>
          Your settings will appear here.
        </p>
      </div>
      <div
        className={`flex items-center gap-2 border p-3 rounded-lg ${
          darkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-300"
        }`}
      >
        <button
          className="cursor-pointer capitalize text-sm bg-gradient-to-br from-blue-500 to-blue-700 hover:to-blue-900 text-white px-3 py-2 rounded-lg"
          onClick={() => handleExport()}
        >
          Export posts to JSON
        </button>
        <label
          className={`cursor-pointer capitalize text-sm transition-all duration-300 ${
            darkMode
              ? "text-gray-400 hover:bg-gray-700 hover:text-gray-300"
              : "hover:bg-gray-100"
          } border border-gray-300 px-3 py-2 rounded-lg`}
        >
          Import posts from JSON
          <input
            type="file"
            accept="application/json"
            className="hidden"
            onChange={handleImport}
          />
        </label>
      </div>
    </div>
  );
};

export default MainBody;
