import AdminLayout from "../../../layouts/AdminLayout";
import MainBody from "./MainBody";
import "./Settings.css";

const Settings = () => {
  return <AdminLayout mainBody={<MainBody />} />;
};

export default Settings;
