import AdminLayout from "../../layouts/AdminLayout";
import Posts from "./posts/Posts";
import "./AdminDashboard.css";

const AdminDashboard = () => {
  return <AdminLayout mainBody={<Posts />} />;
};

export default AdminDashboard;
