import AdminLayout from "../../../layouts/AdminLayout";
import MainBody from "./MainBody";
import "./EditPost.css";
import { useParams } from "react-router-dom";

const EditPost = () => {
  
  const { id } = useParams();

  return <AdminLayout mainBody={<MainBody postId={id} />} />;
};

export default EditPost;
