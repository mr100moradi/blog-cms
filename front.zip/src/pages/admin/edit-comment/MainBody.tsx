import { useEffect, useState, useContext } from "react";
import "./MainBody.css";
import Api from "../../../utils/Api";
import axios from "axios";
import { Link, useNavigate, useParams } from "react-router-dom";
import { MyContext } from "../MyContext";

const MainBody = (props: any) => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { darkMode } = context;
  const { id } = useParams();

  const [comment, setComment] = useState("");
  const [userId, setUserId] = useState(null);

  const navigate = useNavigate();

  const getComment = async () => {
    const config = {
      method: "GET",
      url: `${Api}/comment/single/${id}`,
    };
    await axios(config)
      .then((result) => {
        console.log(result.data);
        setComment(result.data.comment);
      })
      .catch((error) => console.log(error));
  };

  const handleSubmit = async (e: any) => {
    e.preventDefault();

    const config = {
      method: "PUT",
      url: `${Api}/comment/update/${id}`,
      data: {
        comment,
      },
    };
    await axios(config)
      .then((result) => {
        // console.log(result.data);
        navigate("/admin/comments");
      })
      .catch((error) => console.log(error));
  };

  useEffect(() => {
    getComment();
  }, []);

  return (
    <div className="zoomBody w-full flex flex-col px-7 space-y-5">
      <div className="flex justify-between items-center">
        <div>
          <h3 className={`capitalize font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>Edit comment</h3>
          <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-700'}`}>Enter comment.</p>
        </div>
        <Link
          to="/admin/comments"
          className={`cursor-pointer border rounded-lg px-2 py-1 transition-all ${
            darkMode 
              ? 'border-gray-600 hover:bg-gray-700 text-gray-300' 
              : 'border-gray-300 hover:bg-gray-100'
          }`}
        >
          Back to comments
        </Link>
      </div>
      <div className={`rounded-xl border p-6 shadow-sm ${
        darkMode 
          ? 'border-gray-700 bg-gray-800' 
          : 'border-gray-200 bg-white'
      }`}>
        <form onSubmit={(e) => handleSubmit(e)} className="space-y-4">
          <div>
            <label className={`mb-1 block text-sm font-medium ${darkMode ? 'text-gray-300' : 'text-gray-900'}`}>Content</label>
            <input
              className={`w-full border rounded-lg p-2 text-sm focus:border-blue-500 ${
                darkMode 
                  ? 'border-gray-600 bg-gray-700 text-white placeholder-gray-400' 
                  : 'border-gray-300'
              }`}
              placeholder="Write your comment..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Link
              to="/admin/comments"
              className={`cursor-pointer text-sm border rounded-lg px-2 py-1 transition-all ${
                darkMode 
                  ? 'border-gray-600 hover:bg-gray-700 text-gray-300' 
                  : 'border-gray-300 hover:bg-gray-100'
              }`}
            >
              Cancel
            </Link>
            <button
              type="submit"
              className="cursor-pointer text-sm bg-gradient-to-br from-blue-500 to-blue-700 hover:to-blue-900 text-white px-3 py-1 rounded-lg"
            >
              Save comment
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default MainBody;
