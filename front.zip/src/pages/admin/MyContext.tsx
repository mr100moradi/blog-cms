import React from "react";

export interface User {
  _id: String;
  name: String;
  lastName: String;
  email: { type: String; unique: true };
  userType: String;
  password: String;
  skills: { type: [String]; default: [] };
}

// export interface Post {
//   id: number;
//   title: String;
//   content: String;
//   tags: String[];
//   category_id: number;
//   status: String;
//   image: String;
//   created_at: Date | null;
//   updated_at: Date | null;
// }

export interface MyContextValue {
  openOverlay: boolean;
  setOpenOverlay: (value: boolean) => void;
  activeTab: string;
  setActiveTab: (value: string) => void;
  countPublished: number;
  setCountPublished: (value: number) => void;
  countDraft: number;
  setCountDraft: (value: number) => void;
  countCategories: number;
  setCountCategories: (value: number) => void;
  countComments: number;
  setCountComments: (value: number) => void;
  user: User | null;
  setUser: (value: User) => void;
  darkMode: boolean;
  setDarkMode: (value: boolean) => void;
}

export const MyContext = React.createContext<MyContextValue | undefined>(
  undefined
);
