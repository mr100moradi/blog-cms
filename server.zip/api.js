const express = require("express");
const bodyParser = require('body-parser');
// const ConnectDb = require("./config/connection");
require("dotenv").config();
const cors = require("cors");

const app = express();

const port = process.env.PORT || 5000;

// ConnectDb();

app.use(express.json());

app.use(cors());

app.use(bodyParser.json());

app.use("/user", require("./routes/user"));
app.use("/post", require("./routes/post"));
// app.use("/job", require("./routes/job"));
// app.use("/project", require("./routes/project"));
// app.use("/applicant", require("./routes/applicant"));
// app.use("/api/v1/blog", require("./routes/blog"));
app.use("/category", require("./routes/category"));
app.use("/comment", require("./routes/comment"));

// uploads
app.use("/uploads", express.static("postFile"));
// uploads


app.listen(port, console.log(`app is listening on ${port}`));
