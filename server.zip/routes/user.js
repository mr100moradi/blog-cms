const Router = require("express");
const UserController = require("../controllers/userController");
const { requireSignIn } = require("../helper/AuthMiddleware");
const router = new Router();

router.get("/getAllUser", requireSignIn, UserController.getAllUser);
router.get("/getUser/:id", UserController.getUser);
router.post("/register", UserController.register);
router.post("/login", UserController.login);
// router.get("/mobileProfile", requireSignIn, UserController.mobileProfile);
// router.get("/manager", requireSignIn, UserController.manager);
// router.put("/forgetPassword", UserController.forgetPassword);
router.put("/updateProfile/:id", UserController.updateProfile);

module.exports = router;
