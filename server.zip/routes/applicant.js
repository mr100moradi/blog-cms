const Router = require("express");
const ApplicantController = require("../controllers/applicantController");
const router = new Router();

router.get("/:code", ApplicantController.get);
router.post("/add", ApplicantController.add);
router.get("/single/:code", ApplicantController.single);
router.put("/update/:code", ApplicantController.update);
router.delete("/delete/:jobCode", ApplicantController.deleteObj);
router.get("/searchJob/:searchText", ApplicantController.searchJob);
router.get("/searchProject/:searchText", ApplicantController.searchProject);

module.exports = router;
