const Router = require("express");
const BlogController = require("../controllers/blogController");
const router = new Router();

router.get("/", BlogController.get);
router.post("/add", BlogController.add);
router.get("/single/:id", BlogController.single);
router.put("/update/:id", BlogController.update);
router.delete("/delete/:id", BlogController.deleteBlog);

module.exports = router;
