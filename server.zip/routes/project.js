const Router = require("express");
const ProjectController = require("../controllers/projectController");
const router = new Router();

router.get("/", ProjectController.get);
router.post("/add", ProjectController.add);
router.get("/single/:id", ProjectController.single);
router.put("/update/:id", ProjectController.update);
router.delete("/delete/:id", ProjectController.deleteObj);
router.get("/search/:searchText", ProjectController.search);

module.exports = router;
