const Router = require("express");
const JobController = require("../controllers/jobController");
const router = new Router();


router.get("/", JobController.get);
router.post("/add", JobController.add);
router.get("/single/:id", JobController.single);
router.put("/update/:id", JobController.update);
router.delete("/delete/:id", JobController.deleteObj);
router.get("/search/:searchText", JobController.search);

module.exports = router;
