const express = require('express');
const router = express.Router();
const CommentController = require('../controllers/commentController');

router.get('/', CommentController.get);
router.post('/add', CommentController.add);
router.get('/single/:id', CommentController.single);
router.put('/update/:id', CommentController.update);
router.delete('/delete/:id', CommentController.deleteComment);
router.get('/countComments', CommentController.getCountComments);
router.get('/commentsByPostId/:postId', CommentController.getCommentsByPostId);


module.exports = router;
