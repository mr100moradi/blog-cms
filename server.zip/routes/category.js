const Router = require("express");
const CategoryController = require("../controllers/categoryController");
const router = new Router();

router.get("/", CategoryController.get);
router.post("/add", CategoryController.add);
router.get("/single/:id", CategoryController.single);
router.put("/update/:id", CategoryController.update);
router.delete("/delete/:id", CategoryController.deleteUser);
router.get("/countCategories", CategoryController.getCountCategories);

module.exports = router;
