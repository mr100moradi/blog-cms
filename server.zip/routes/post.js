// const Router = require("express");
// const multer = require("multer");
// const PostController = require("../controllers/postController");
// const router = new Router();

// const storage = multer.diskStorage({
//   destination: function (req, file, cb) {
//     cb(null, "postFile/");
//   },
//   filename: function (req, file, cb) {
//     const uniqueName = Date.now();
//     cb(null, uniqueName + file.originalname);
//   },
// });

// const uploads = multer({
//   storage: storage,
// }).fields([{ name: "postFile", maxCount: 1 }]);

// router.get("/", PostController.get);
// router.post("/add", uploads, PostController.add);
// router.get("/single/", PostController.single);
// // router.put("/update/:id", uploads, PostController.update);
// router.delete("/delete/:id", PostController.deleteObj);
// router.get("/search/:searchText", PostController.search);

// module.exports = router;



const express = require('express');
const multer = require("multer");
const router = express.Router();
const PostController = require('../controllers/postController');

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "postFile/");
  },
  filename: function (req, file, cb) {
    const uniqueName = Date.now();
    cb(null, uniqueName + file.originalname);
  },
});

const uploads = multer({
  storage: storage,
}).fields([{ name: "image", maxCount: 1 }]);

router.get('/', PostController.get);
router.post('/add', uploads, PostController.add);
router.get('/single/:id', PostController.single);
router.put('/update/:id', uploads, PostController.update);
router.delete('/delete/:id', PostController.deletePost);
router.get('/countPublished', PostController.getCountPublished);
router.get('/countDraft', PostController.getCountDrafted);
router.delete('/deleteAllPosts', PostController.deleteAllPosts);
router.post('/insertAllPosts', PostController.insertAllPosts);


module.exports = router;
