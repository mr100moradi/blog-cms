const pool = require("../config/connection");

// Read all comments
const get = async (req, res) => {
  try {
    const [rows] = await pool.execute("SELECT * FROM comments");

    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Create a new post
const add = async (req, res) => {
  try {
    const { fullName, comment, postId } = req.body;

    const [result] = await pool.execute(
      "INSERT INTO comments (name, comment, post_id, created_at) VALUES (?, ?, ?, ?)",
      [fullName, comment, postId, new Date()]
    );
    const id = result.insertId;
    res.status(201).json({ id, fullName, postId, comment });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Read single post by id
const single = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute("SELECT * FROM comments WHERE id = ?", [
      id,
    ]);
    if (rows.length === 0)
      return res.status(404).json({ error: "Comment not found" });

    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Update post
const update = async (req, res) => {
  try {
    const { id } = req.params;

    const { name, comment } = req.body;

    const [result] = await pool.execute(
      "UPDATE comments SET comment = ?, updated_at = ? WHERE id = ?",
      [comment, new Date(), id]
    );
    if (result.affectedRows === 0)
      return res.status(404).json({ error: "Comment not found" });
    res.json({ id, name, comment });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Delete post
const deleteComment = async (req, res) => {
  try {
    const { id } = req.params;
    const [result] = await pool.execute("DELETE FROM comments WHERE id = ?", [
      id,
    ]);
    if (result.affectedRows === 0)
      return res.status(404).json({ error: "Comment not found" });
    res.json({ message: "Comment deleted" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// get count draft comments
const getCountComments = async (req, res) => {
  try {
    const [rows] = await pool.execute(
      "SELECT COUNT(id) as count_comments FROM comments"
    );

    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const getCommentsByPostId = async (req, res) => {
  try {
    const { postId } = req.params;

    const [rows] = await pool.execute(
      "SELECT * FROM comments WHERE post_id = ?",
      [postId]
    );

    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

module.exports = {
  get,
  add,
  single,
  update,
  deleteComment,
  getCountComments,
  getCommentsByPostId
};
