const pool = require("../config/connection");

// Read all category
const get = async (req, res) => {
  try {
    const [rows] = await pool.execute(
      "SELECT * FROM categories"
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Create a new category
const add = async (req, res) => {
  try {
    const { name } = req.body;
    const [result] = await pool.execute(
      "INSERT INTO categories (name, created_at) VALUES (?, ?)",
      [name, new Date()]
    );
    const id = result.insertId;
    res.status(201).json({ id, name });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Read single category by id
const single = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute(
      "SELECT * FROM categories WHERE id = ?",
      [id]
    );
    if (rows.length === 0)
      return res.status(404).json({ error: "User not found" });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Update category
const update = async (req, res) => {
  try {
    const { id } = req.params;
    const { name } = req.body;
    const [result] = await pool.execute(
      "UPDATE categories SET name = ?, updated_at = ? WHERE id = ?",
      [name, new Date(), id]
    );
    if (result.affectedRows === 0)
      return res.status(404).json({ error: "User not found" });
    res.json({ id, name });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Delete category
const deleteUser = async (req, res) => {
  try {
    const { id } = req.params;
    const [result] = await pool.execute("DELETE FROM categories WHERE id = ?", [id]);
    if (result.affectedRows === 0)
      return res.status(404).json({ error: "User not found" });
    res.json({ message: "User deleted" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// get count categories
const getCountCategories = async (req, res) => {
  try {
    const [rows] = await pool.execute("SELECT COUNT(id) as count_categories FROM categories");

    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

module.exports = {
  get,
  add,
  single,
  update,
  deleteUser,
  getCountCategories
};