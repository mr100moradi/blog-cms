const pool = require("../config/connection");

// Read all posts
const get = async (req, res) => {
  try {
    const [rows] = await pool.execute("SELECT * FROM posts");

    const processed = rows.map((row) => {
      let parsedTags = [];
      try {
        parsedTags = row.tags ? JSON.parse(row.tags) : [];
      } catch (e) {
        parsedTags = [];
      }
      return {
        ...row,
        tags: parsedTags,
      };
    });

    res.json(processed);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Create a new post
const add = async (req, res) => {
  try {
    const { title, content, tags, categoryId, status, image } = req.body;

    const imageFile = req.files.image ? req.files.image[0].filename : null;

    const [result] = await pool.execute(
      "INSERT INTO posts (title, content, tags, category_id, status, image, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [
        title,
        content,
        JSON.stringify(tags),
        categoryId,
        status,
        imageFile,
        new Date(),
      ],
    );
    const id = result.insertId;
    res
      .status(201)
      .json({ id, title, content, tags, categoryId, status, imageFile });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Read single post by id
const single = async (req, res) => {
  try {
    const { id } = req.params;

    const [rows] = await pool.execute("SELECT * FROM posts WHERE id = ?", [id]);
    if (rows.length === 0)
      return res.status(404).json({ error: "Post not found" });

    const processed = rows.map((row) => {
      let parsedTags = [];
      try {
        parsedTags = row.tags ? JSON.parse(row.tags) : [];
      } catch (e) {
        parsedTags = [];
      }
      return {
        ...row,
        tags: parsedTags,
      };
    });

    res.json(processed[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Update post
const update = async (req, res) => {
  try {
    const { id } = req.params;

    const { title, content, tags, categoryId, status, image } = req.body;

    const imageFile = req.files.image ? req.files.image[0].filename : null;

    let result = null;

    if (imageFile) {
      result = await pool.execute(
        "UPDATE posts SET title = ?, content = ?, tags = ?, category_id = ?, status = ?, image = ?, updated_at = ? WHERE id = ?",
        [
          title,
          content,
          JSON.stringify(tags),
          categoryId,
          status,
          imageFile,
          new Date(),
          id,
        ],
      );
    } else {
      result = await pool.execute(
        "UPDATE posts SET title = ?, content = ?, tags = ?, category_id = ?, status = ?, updated_at = ? WHERE id = ?",
        [
          title,
          content,
          JSON.stringify(tags),
          categoryId,
          status,
          new Date(),
          id,
        ],
      );
    }

    if (result.affectedRows === 0)
      return res.status(404).json({ error: "Post not found" });
    res.json({ id, title, content, tags, categoryId, status, imageFile });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Delete post
const deletePost = async (req, res) => {
  try {
    const { id } = req.params;
    const [result] = await pool.execute("DELETE FROM posts WHERE id = ?", [id]);
    if (result.affectedRows === 0)
      return res.status(404).json({ error: "Post not found" });
    res.json({ message: "Post deleted" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// get count published posts
const getCountPublished = async (req, res) => {
  try {
    const [rows] = await pool.execute(
      "SELECT COUNT(id) as count_published FROM posts WHERE status = 'published'",
    );

    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// get count draft posts
const getCountDrafted = async (req, res) => {
  try {
    const [rows] = await pool.execute(
      "SELECT COUNT(id) as count_draft FROM posts WHERE status = 'draft'",
    );

    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// delete all posts
const deleteAllPosts = async (req, res) => {
  try {
    const [rows] = await pool.execute("DELETE FROM posts");

    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err });
  }
};

// insert all posts
const insertAllPosts = async (req, res) => {
  const { data } = req.body;

  // Build placeholders and values
  const placeholders = data.map(() => "(?, ?, ?, ?, ?, ?, ?, ?, ?)").join(", ");
  const values = data.flatMap((d) => [
    d.id,
    d.title,
    d.content,
    JSON.stringify(d.tags),
    d.category_id,
    d.status,
    d.image,
    d.created_at,
    d.updated_at,
  ]);

  const [result] = await pool.execute(
    `INSERT INTO posts (id, title, content, tags, category_id, status, image, created_at, updated_at) VALUES ${placeholders}`,
    values,
  );

  console.log("Inserted rows:", result.affectedRows);
  res.json(result);
};

module.exports = {
  get,
  add,
  single,
  update,
  deletePost,
  getCountPublished,
  getCountDrafted,
  deleteAllPosts,
  insertAllPosts,
};
