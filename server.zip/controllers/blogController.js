const Blog = require("../models/blogModel");

const get = async (req, res) => {
  const blogs = await Blog.find().sort({ createdAt: "desc" });
  return res.json(blogs);
};

const add = async (req, res) => {
  try {
    const { title, desc, shortDesc, write, category, mainImg } = req.body;

    switch (true) {
      case !title:
        return res.status(500).send({ error: "عنوان الزامی است" });
      case !desc:
        return res.status(500).send({ error: "توضیحات الزامی است" });
    }

    const data = await new Blog({
      title,
      desc,
      shortDesc,
      write,
      category,
      mainImg,
    });
    await data.save();

    return res.json({
      status: 200,
      success: true,
      message: `مقاله با عنوان ${data.title} با موفقیت ثبت شد`,
      data,
    });
  } catch (error) {
    console.log(error);
  }
};

const single = async (req, res) => {
  try {
    const result = await Blog.findById(req.params.id);
    return res.json(result);
  } catch (error) {
    console.log(error);
  }
};

const update = async (req, res) => {
  try {
    const blogId = req.params.id;
    const updateBlog = req.body;
    const result = await Blog.findByIdAndUpdate(blogId, updateBlog);
    return res.json({
      status: 200,
      success: true,
      message: `مقاله با موفقیت بروز شد`,
      result,
    });
  } catch (error) {
    console.log(error);
  }
};

const deleteBlog = async (req, res) => {
  try {
    const result = await Blog.findByIdAndDelete(req.params.id);
    return res.json({
      status: 200,
      success: true,
      message: `مقاله با موفقیت حذف شد`,
      result,
    });
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  get,
  add,
  single,
  update,
  deleteBlog
};
