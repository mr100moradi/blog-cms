const pool = require("../config/connection");
const { hashPassword, comparePassword } = require("../helper/AuthHelper");
const JWT = require("jsonwebtoken");

const getAllUser = async (req, res) => {
  try {
    const [rows] = await pool.execute("SELECT * FROM users");

    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const getUser = async (req, res) => {
  try {
    const { id } = req.params;

    const [rows] = await pool.execute("SELECT * FROM users WHERE id = ?", [id]);
    if (rows.length === 0)
      return res.status(404).json({ error: "User not found" });

    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const register = async (req, res) => {
  try {
    const { firstName, lastName, email, password, confirmPassword, userType } =
      req.body;

    switch (true) {
      case !firstName:
        return res.json({ message: "First name required" });
      case !lastName:
        return res.json({ message: "Last name required" });
      case !userType:
        return res.json({ message: "User type required" });
      case !email:
        return res.json({ message: "Email required" });
      case !password:
        return res.json({ message: "Password required" });
      case password !== confirmPassword:
        return res.json({
          message: "Password is not equal with confirm password",
        });
    }

    // check User
    const existingUser = await pool.execute(
      "SELECT * FROM users WHERE email = ?",
      [email]
    );
    if (existingUser[0].length > 0) {
      return res.json({
        status: 500,
        success: false,
        message: "Email beforely existed",
      });
    }

    const hashedPassword = await hashPassword(password);

    const result = await pool.execute(
      "INSERT INTO users (first_name, last_name, email , password, user_type, created_at) VALUES (?, ?, ?, ?, ?, ?)",
      [firstName, lastName, email, hashedPassword, userType, new Date()]
    );
    const id = result.insertId;

    const token = await JWT.sign({ id: id }, process.env.JWT_SECRET, {
      expiresIn: "7d",
    });

    const user = await pool.execute("SELECT * FROM users WHERE email = ?", [
      email,
    ]);

    return res.json({
      status: 200,
      success: true,
      message: `${user[0][0].first_name} ${user[0][0].last_name} welcome to simple blog cms`,
      user: user[0][0],
      token,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // validation
    if (!email || !password) {
      return res.json({
        success: false,
        message: "Enter required fields",
      });
    }

    const user = await pool.execute("SELECT * FROM users WHERE email = ?", [
      email,
    ]);
    if (user[0].length === 0) {
      return res.json({
        success: false,
        message: `User with email ${email} is not found`,
      });
    }

    const match = await comparePassword(password, user[0][0].password);

    if (!match) {
      return res.json({
        success: false,
        message: "Password is not valid",
      });
    }

    const token = await JWT.sign(
      { id: user[0][0].id },
      process.env.JWT_SECRET,
      {
        expiresIn: "7d",
      }
    );

    res.status(200).send({
      success: true,
      user: user[0][0],
      message: `Welcome ${user[0][0].first_name} ${user[0][0].last_name}`,
      token,
    });
  } catch (error) {
    console.log(error);
  }
};

// const mobileProfile = async (req, res) => {
//   try {
//     const user = await User.findById(req.user._id);

//     return res.json({
//       _id: user._id,
//       name: user.name,
//       lastName: user.lastName,
//       email: user.email,
//       phone: user.phone,
//       address: user.address,
//       username: user.username,
//       user,
//     });
//   } catch (error) {
//     console.log(error);
//   }
// };

// const manager = async (req, res) => {
//   try {
//     const admin = await User.findById(req.user._id);

//     if (admin.isAdmin) {
//       return res.json({
//         _id: admin._id,
//         name: admin.name,
//         lastName: admin.lastName,
//         email: admin.email,
//         phone: admin.phone,
//         address: admin.address,
//         username: admin.username,
//         admin,
//       });
//     } else {
//       res.status(404).send({
//         message: "کاربری با این اطلاعات وجود ندارد",
//       });
//     }
//   } catch (error) {
//     console.log(error);
//     res.status(404).send({
//       message: "کاربری با این اطلاعات وجود ندارد",
//     });
//   }
// };

// const forgetPassword = async (req, res) => {
//   try {
//     const { email, password } = req.body;

//     switch (true) {
//       case !email:
//         return res.json({ message: "ایمیل ضروریست" });
//       case !password:
//         return res.json({ message: "کلمه عبور ضروریست" });
//     }

//     const user = await User.findOne({ email });

//     if (!user) {
//       return res.json({
//         status: 404,
//         success: false,
//         message: "کاربری با این ایمیل یافت نشد",
//       });
//     } else {
//       const hashed = await hashPassword(password);

//       await User.findByIdAndUpdate(user._id, { password: hashed });

//       res.json({
//         status: 201,
//         success: true,
//         message: "رمز عبور با موفقیت ویرایش شد",
//       });
//     }
//   } catch (error) {
//     console.log(error);
//   }
// };

const updateProfile = async (req, res) => {
  try {
    const { skills } = req.body;

    const userId = req.params.id;

    const result = await User.findById(userId);

    if (!result) {
      return res.json({
        status: 404,
        success: false,
        message: "Not founded user with this id",
      });
    }

    result.skills = skills;
    result.updatedAt = Date.now();

    await result.save();

    res.json({
      status: 200,
      success: true,
      message: "User successfully updated",
    });
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  getAllUser,
  getUser,
  register,
  login,
  updateProfile,
};
// manager,
// forgetPassword,
