const mongoose = require("mongoose");

const applicant = new mongoose.Schema({
  jobCode: { type: String, required: false },
  projectCode: { type: String, required: false },
  employerId: { type: String, required: false },
  employeeId: { type: String, required: false },
  // jobStatus: { type: String, required: false },
  // projectStatus: { type: String, required: false },
  applyStatus: { type: String, required: false },
  createdAt: { type: Date, required: false },
  updatedAt: { type: Date, required: false },
});

const Applicant = mongoose.model("Applicant", applicant);

module.exports = Applicant;
