const mongoose = require("mongoose");

const user = new mongoose.Schema({
  name: String,
  lastName: String,
  email: { type: String, unique: true },
  userType: String,
  password: String,
  skills: { type: [String], default: [] },
  createdAt: { type: Date, required: false },
  updatedAt: { type: Date, required: false },
});

const User = mongoose.model("User", user);

module.exports = User;
