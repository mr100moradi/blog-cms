const mongoose = require("mongoose");

const blog = new mongoose.Schema({
  title: String,
  desc: String,
  shortDesc: String,
  writer: String,
  category: String,
  mainImg: String,
  createdAt: { type: Date, required: false },
});

const Blog = mongoose.model("Blog", blog);

module.exports = Blog;
