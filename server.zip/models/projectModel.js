const mongoose = require("mongoose");

const project = new mongoose.Schema({
  projectCode: String,
  title: String,
  category: String,
  salary: String,
  location: String,
  duration: String,
  skills: { type: [String], default: [], required: false },
  paymentMethod: String,
  description: String,
  employerId: { type: String, required: false },
  projectStatus: { type: String, required: false },
  createdAt: { type: Date, required: false },
  updatedAt: { type: Date, required: false },
});

const Project = mongoose.model("Project", project);

module.exports = Project;
