const mongoose = require("mongoose");

const category = new mongoose.Schema({
  title: String,
  mainImg: String,
  createdAt: { type: Date, default: Date.now() },
});

const Category = mongoose.model("Category", category);

module.exports = Category;
