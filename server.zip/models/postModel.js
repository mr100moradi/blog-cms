const mongoose = require("mongoose");

const post = new mongoose.Schema({
  userId: String,
  title: String,
  postFile: String,
  createdAt: { type: Date, required: false },
});

const Post = mongoose.model("Post", post);

module.exports = Post;
