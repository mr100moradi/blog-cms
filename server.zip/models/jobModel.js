const mongoose = require("mongoose");

const job = new mongoose.Schema({
  jobCode: String,
  title: String,
  category: String,
  salary: String,
  location: String,
  duration: String,
  skills: { type: [String], default: [], required: false },
  paymentMethod: String,
  description: String,
  employerId: { type: String, required: false },
  jobStatus: { type: String, required: false },
  createdAt: { type: Date, required: false },
  updatedAt: { type: Date, required: false },
});

const Job = mongoose.model("Job", job);

module.exports = Job;
