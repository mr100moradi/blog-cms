// const User = require("../models/userModel");
const pool = require("../config/connection");

const JWT = require("jsonwebtoken");

const requireSignIn = async (req, res, next) => {
  let token;

  try {
    if (
      req.headers.authorization &&
      req.headers.authorization.startsWith("Bearer")
    ) {
      token = req.headers.authorization.split(" ")[1];

      const decoded = JWT.verify(token, process.env.JWT_SECRET);

      req.user = await pool.execute("SELECT password FROM users WHERE id = ?", [decoded.id]);
      // req.user = await User.findById(decoded.id).select("-password");

      req.user = decoded;

      next();
    }
  } catch (error) {
    console.log(error);
  }
};

module.exports = { requireSignIn };
