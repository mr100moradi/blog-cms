// const mongoose = require("mongoose");

// const ConnectDb = async () => {
//   try {
//     await mongoose.connect(`mongodb://0.0.0.0:27017/${process.env.DB_PORT}`);
//     console.log("database connected successfully");
//   } catch (error) {
//     console.log(error);
//   }
// };

// module.exports = ConnectDb;


require('dotenv').config();
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'blog_cms',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

module.exports = pool;